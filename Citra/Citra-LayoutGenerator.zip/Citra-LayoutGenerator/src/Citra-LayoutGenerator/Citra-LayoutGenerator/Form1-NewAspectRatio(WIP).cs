﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Citra_LayoutGenerator
{
    public partial class Form1 : Form
    {
        public const int topScrWidthDef = 400;
        public const int topScrHeightDef = 240;
        public const int bottomScrWidthDef = 320;
        public const int bottomScrHeightDef = 240;

        public Form1()
        {
            InitializeComponent();

            //Windows only
            //textBox8.Text = "C:\\Users\\" + Environment.UserName + "\\AppData\\Roaming\\Citra\\config\\qt-config.ini";

            // Construct the path to qt-config.ini in a cross-platform manner
            string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string configFilePath = Path.Combine(appDataPath, "Citra", "config", "qt-config.ini");
            textBox8.Text = configFilePath;
        }

        private void button1_Click(object sender, EventArgs e) // "generate (centered)"
        {
            ValidateInputs();

            int screenSep = GetEvenIntegerInput(textBox7);
            int screenSep2 = screenSep / 2;
            int screenW = GetIntegerInput(textBox5);
            int screenH = GetIntegerInput(textBox6);
            int topsW = GetIntegerInput(textBox1);
            int topsH = GetIntegerInput(textBox2);
            int btmsW = GetIntegerInput(textBox3);
            int btmsH = GetIntegerInput(textBox4);

            richTextBox1.Clear();

            int topScreenLeftRight = (screenW - topsW) / 2;
            int screenUpDownSize = (screenH - topsH - btmsH) / 2 - screenSep2;
            int topRightSize = topScreenLeftRight + topsW;
            int topBottomSize = screenUpDownSize + topsH;

            int bottomScreenLeftRight = (screenW - btmsW) / 2;
            int bottomTopSize = topBottomSize + screenSep;
            int bottomRightSize = bottomScreenLeftRight + btmsW;
            int bottomBottomSize = screenH - screenUpDownSize;

            if (topScreenLeftRight < 0 || screenUpDownSize < 0 || topRightSize < 0 || topBottomSize < 0
                || bottomScreenLeftRight < 0 || bottomTopSize < 0 || bottomRightSize < 0 || bottomBottomSize < 0)
            {
                MessageBox.Show("At least one of the calculated values was negative! Check if the screen resolutions are optimized properly.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string[] layoutLines = {
                "custom_layout\\default=false",
                "custom_layout=true",
                "custom_top_left\\default=false",
                $"custom_top_left={topScreenLeftRight}",
                "custom_top_top\\default=false",
                $"custom_top_top={screenUpDownSize}",
                "custom_top_right\\default=false",
                $"custom_top_right={topRightSize}",
                "custom_top_bottom\\default=false",
                $"custom_top_bottom={topBottomSize}",
                "custom_bottom_left\\default=false",
                $"custom_bottom_left={bottomScreenLeftRight}",
                "custom_bottom_top\\default=false",
                $"custom_bottom_top={bottomTopSize}",
                "custom_bottom_right\\default=false",
                $"custom_bottom_right={bottomRightSize}",
                "custom_bottom_bottom\\default=false",
                $"custom_bottom_bottom={bottomBottomSize}"
            };

            richTextBox1.Lines = layoutLines;

            //MessageBox.Show("Layout values calculated and added to the textbox!", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button2_Click(object sender, EventArgs e) // "generate (side-by-side)"
        {
            int screenW = GetIntegerInput(textBox5);
            int screenH = GetIntegerInput(textBox6);
            int topsW = GetIntegerInput(textBox1);
            int topsH = GetIntegerInput(textBox2);
            int btmsW = GetIntegerInput(textBox3);
            int btmsH = GetIntegerInput(textBox4);
            int screenSep = GetEvenIntegerInput(textBox7);
            int screenSep2 = screenSep / 2;

            richTextBox1.Clear();

            int topScreenLeftRight = (screenW - (topsW + btmsW)) / 2 - screenSep2;
            int screenUpDownSize = (screenH - topsH) / 2;
            int topRightSize = topScreenLeftRight + topsW;
            int topBottomSize = screenUpDownSize + topsH;

            int bottomScreenLeftRight = topRightSize + screenSep;
            int bottomTopSize = (screenH - btmsH) / 2;
            int bottomRightSize = screenW - topScreenLeftRight;
            int bottomBottomSize = bottomTopSize + btmsH;

            if (topScreenLeftRight < 0 || screenUpDownSize < 0 || topRightSize < 0 || topBottomSize < 0
                || bottomScreenLeftRight < 0 || bottomTopSize < 0 || bottomRightSize < 0 || bottomBottomSize < 0)
            {
                MessageBox.Show("At least one of the calculated values was in minus! Check if the screen resolutions are optimized properly.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string[] layoutLines = {
                "custom_layout\\default=false",
                "custom_layout=true",
                "custom_top_left\\default=false",
                $"custom_top_left={topScreenLeftRight}",
                "custom_top_top\\default=false",
                $"custom_top_top={screenUpDownSize}",
                "custom_top_right\\default=false",
                $"custom_top_right={topRightSize}",
                "custom_top_bottom\\default=false",
                $"custom_top_bottom={topBottomSize}",
                "custom_bottom_left\\default=false",
                $"custom_bottom_left={bottomScreenLeftRight}",
                "custom_bottom_top\\default=false",
                $"custom_bottom_top={bottomTopSize}",
                "custom_bottom_right\\default=false",
                $"custom_bottom_right={bottomRightSize}",
                "custom_bottom_bottom\\default=false",
                $"custom_bottom_bottom={bottomBottomSize}"
            };

            richTextBox1.Lines = layoutLines;

            //MessageBox.Show("Layout values calculated and added to the textbox!", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Declare the aspectRatios list
        /*private List<AspectRatioConfiguration> aspectRatios = new List<AspectRatioConfiguration>
        {
                new AspectRatioConfiguration(2, 1),
                new AspectRatioConfiguration(4, 3),
                new AspectRatioConfiguration(3, 2),
                new AspectRatioConfiguration(5, 3),
                new AspectRatioConfiguration(5, 4),
                new AspectRatioConfiguration(8, 5),
                new AspectRatioConfiguration(9, 5),
                new AspectRatioConfiguration(16, 9),
                new AspectRatioConfiguration(16, 10),
                new AspectRatioConfiguration(21, 9),
                new AspectRatioConfiguration(25, 11),
                new AspectRatioConfiguration(25, 12),
                new AspectRatioConfiguration(25, 16),
                new AspectRatioConfiguration(32, 9),
                new AspectRatioConfiguration(32, 10),
                new AspectRatioConfiguration(32, 25),
                new AspectRatioConfiguration(64, 27),
                new AspectRatioConfiguration(70, 30)
        };*/

        private void button3_Click(object sender, EventArgs e) // "generate (in set...)"
        {
            int screenW = GetIntegerInput(textBox5);
            int screenH = GetIntegerInput(textBox6);
            int btmsW = GetIntegerInput(textBox3);
            int btmsH = GetIntegerInput(textBox4);

            if (btmsW > screenW)
            {
                MessageBox.Show("The bottom screen's width is bigger than the screen resolution's width!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            richTextBox1.Clear();

            List<AspectRatioConfiguration> aspectRatios = new List<AspectRatioConfiguration>
            {
                new AspectRatioConfiguration(2, 1),
                new AspectRatioConfiguration(4, 3),
                new AspectRatioConfiguration(3, 2),
                new AspectRatioConfiguration(5, 3),
                new AspectRatioConfiguration(5, 4),
                new AspectRatioConfiguration(8, 5),
                new AspectRatioConfiguration(9, 5),
                new AspectRatioConfiguration(16, 9),
                new AspectRatioConfiguration(16, 10),
                new AspectRatioConfiguration(21, 9),
                new AspectRatioConfiguration(25, 11),
                new AspectRatioConfiguration(25, 12),
                new AspectRatioConfiguration(25, 16),
                new AspectRatioConfiguration(32, 9),
                new AspectRatioConfiguration(32, 10),
                new AspectRatioConfiguration(32, 25),
                new AspectRatioConfiguration(64, 27),
                new AspectRatioConfiguration(70, 30)
            };

            // Calculate the actual aspect ratio of the screen resolution
            //float calculatedAspectRatio = (float)screenW / screenH;

            // Find the closest matching aspect ratio from the list
            //AspectRatioConfiguration matchingAspectRatio = FindClosestMatchingAspectRatio(calculatedAspectRatio, aspectRatios);

            AspectRatioConfiguration matchingAspectRatio = FindClosestMatchingAspectRatio(screenW, screenH, aspectRatios);

            if (matchingAspectRatio != null)
            {
                GenerateConfigurationForAspectRatio(matchingAspectRatio, screenW, screenH, btmsW, btmsH);
                InsetCenter();
            }
        }

        static int GCD(int a, int b)
        {
            int Remainder;

            while (b != 0)
            {
                Remainder = a % b;
                a = b;
                b = Remainder;
            }

            return a;
        }

        private AspectRatioConfiguration FindClosestMatchingAspectRatio(int screenW, int screenH, List<AspectRatioConfiguration> aspectRatios)
        {
            // Calculate the GCD of the screen width and height
            int gcd = GCD(screenW, screenH);

            // Simplify the aspect ratio fractions
            int simplifiedWidth = screenW / gcd;
            int simplifiedHeight = screenH / gcd;

            // Find the closest matching aspect ratio from the list based on simplified fractions
            AspectRatioConfiguration closestMatch = aspectRatios
                .OrderBy(ar => Math.Abs((float)ar.Width / ar.Height - (float)simplifiedWidth / simplifiedHeight))
                .FirstOrDefault();

            return closestMatch;
        }

        /*private AspectRatioConfiguration FindClosestMatchingAspectRatio(float calculatedAspectRatio, List<AspectRatioConfiguration> aspectRatios)
        {
            // Define a tolerance value
            float tolerance = 0.03f; // Adjust as needed

            // Find the closest matching aspect ratio from the list based on tolerance
            AspectRatioConfiguration closestMatch = aspectRatios
                .OrderBy(ar => Math.Abs((float)ar.Width / ar.Height - calculatedAspectRatio))
                .FirstOrDefault(ar => Math.Abs((float)ar.Width / ar.Height - calculatedAspectRatio) <= tolerance);

            return closestMatch;
        }*/

        private void GenerateConfigurationForAspectRatio(AspectRatioConfiguration aspectRatio, int screenW, int screenH, int btmsW, int btmsH)
        {
            //MessageBox.Show(aspectRatio.Width.ToString());
            //MessageBox.Show(aspectRatio.Height.ToString());

            float newWidth, newHeight, dif;
            int blackbar, screenRightSize, bottomLeftSize, bottomRightSize, bottomTopSize, bottomBottomSize;

            //
            // EXCEPTIONS FIRST (1366x768, 16:10 common resolutions, 5040x2160 and 21:9)
            //

            // Custom configurations for 1366x768
            if (screenW == 1366 && screenH == 768)
            {
                blackbar = 214;
                screenRightSize = screenW - blackbar;
                bottomLeftSize = 0;
                bottomRightSize = screenRightSize;
                bottomTopSize = 0;
                bottomBottomSize = screenH;

                if (radioButton1.Checked) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                else if (radioButton2.Checked) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                else if (radioButton3.Checked) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                else if (radioButton4.Checked) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                AppendLineWithDefaultFlag("custom_top_left", blackbar.ToString());
                AppendLineWithDefaultFlag("custom_top_top", "0");
                AppendLineWithDefaultFlag("custom_top_right", screenRightSize.ToString());
                AppendLineWithDefaultFlag("custom_top_bottom", screenH.ToString());
                AppendLineWithDefaultFlag("custom_bottom_left", bottomLeftSize.ToString());
                AppendLineWithDefaultFlag("custom_bottom_top", bottomTopSize.ToString());
                AppendLineWithDefaultFlag("custom_bottom_right", bottomRightSize.ToString());
                AppendLineWithDefaultFlag("custom_bottom_bottom", bottomBottomSize.ToString());
            }
            else if (screenW == 1280 && screenH == 800 || screenW == 1440 && screenH == 900 || screenW == 1680 && screenH == 1050 ||
                screenW == 1920 && screenH == 1200 || screenW == 2560 && screenH == 1600 || screenW == 3840 && screenH == 2400)
            {
                newWidth = (float)screenW / 16;
                newHeight = (float)screenH / 10;
                if (newWidth == newHeight)
                {
                    blackbar = (int)Math.Floor(newWidth) / 2;
                    screenRightSize = screenW - blackbar;
                    bottomLeftSize = 0;
                    bottomRightSize = screenRightSize;
                    bottomTopSize = 0;
                    bottomBottomSize = screenH;

                    if (radioButton1.Checked) //bottom right
                    {
                        bottomLeftSize = (screenW - btmsW) - blackbar;
                        bottomTopSize = screenH - btmsH;
                    }
                    else if (radioButton2.Checked) //top right
                    {
                        bottomLeftSize = (screenW - btmsW) - blackbar;
                        bottomBottomSize = btmsH;
                    }
                    else if (radioButton3.Checked) //bottom left
                    {
                        bottomLeftSize = blackbar;
                        bottomTopSize = screenH - btmsH;
                        bottomRightSize = blackbar + btmsW;
                    }
                    else if (radioButton4.Checked) //top left
                    {
                        bottomLeftSize = blackbar;
                        bottomRightSize = blackbar + btmsW;
                        bottomBottomSize = btmsH;
                    }

                    richTextBox1.AppendText("custom_layout\\default=false\r\n");
                    richTextBox1.AppendText("custom_layout=true\r\n");
                    AppendLineWithDefaultFlag("custom_top_left", blackbar.ToString());
                    AppendLineWithDefaultFlag("custom_top_top", "0");
                    AppendLineWithDefaultFlag("custom_top_right", screenRightSize.ToString());
                    AppendLineWithDefaultFlag("custom_top_bottom", screenH.ToString());
                    AppendLineWithDefaultFlag("custom_bottom_left", bottomLeftSize.ToString());
                    AppendLineWithDefaultFlag("custom_bottom_top", bottomTopSize.ToString());
                    AppendLineWithDefaultFlag("custom_bottom_right", bottomRightSize.ToString());
                    AppendLineWithDefaultFlag("custom_bottom_bottom", bottomBottomSize.ToString());
                }
            }
            else if (screenW == 5040 && screenH == 2160)
            {
                newWidth = (float)screenW / 70;
                newHeight = (float)screenH / 30;
                if (newWidth == newHeight)
                {
                    blackbar = (int)Math.Floor(newWidth) / 2;
                    screenRightSize = screenW - blackbar;
                    bottomLeftSize = 0;
                    bottomRightSize = screenRightSize;
                    bottomTopSize = 0;
                    bottomBottomSize = screenH;

                    if (radioButton1.Checked) //bottom right
                    {
                        bottomLeftSize = (screenW - btmsW) - blackbar;
                        bottomTopSize = screenH - btmsH;
                    }
                    else if (radioButton2.Checked) //top right
                    {
                        bottomLeftSize = (screenW - btmsW) - blackbar;
                        bottomBottomSize = btmsH;
                    }
                    else if (radioButton3.Checked) //bottom left
                    {
                        bottomLeftSize = blackbar;
                        bottomTopSize = screenH - btmsH;
                        bottomRightSize = blackbar + btmsW;
                    }
                    else if (radioButton4.Checked) //top left
                    {
                        bottomLeftSize = blackbar;
                        bottomRightSize = blackbar + btmsW;
                        bottomBottomSize = btmsH;
                    }

                    richTextBox1.AppendText("custom_layout\\default=false\r\n");
                    richTextBox1.AppendText("custom_layout=true\r\n");
                    AppendLineWithDefaultFlag("custom_top_left", blackbar.ToString());
                    AppendLineWithDefaultFlag("custom_top_top", "0");
                    AppendLineWithDefaultFlag("custom_top_right", screenRightSize.ToString());
                    AppendLineWithDefaultFlag("custom_top_bottom", screenH.ToString());
                    AppendLineWithDefaultFlag("custom_bottom_left", bottomLeftSize.ToString());
                    AppendLineWithDefaultFlag("custom_bottom_top", bottomTopSize.ToString());
                    AppendLineWithDefaultFlag("custom_bottom_right", bottomRightSize.ToString());
                    AppendLineWithDefaultFlag("custom_bottom_bottom", bottomBottomSize.ToString());
                }
            }
            else if (aspectRatio.Width == 21 && aspectRatio.Height == 9) // Custom configurations for 21:9
            {
                newWidth = (float)screenW / aspectRatio.Width;
                newHeight = (float)screenH / aspectRatio.Height;
                newWidth = (int)Math.Floor(newWidth);
                dif = newWidth - newHeight;
                newWidth = (float)newWidth - dif;
                if (newWidth == newHeight)
                {
                    blackbar = (int)Math.Floor(newWidth) / 2;
                    screenRightSize = screenW - blackbar;
                    bottomLeftSize = 0;
                    bottomRightSize = screenRightSize;
                    bottomTopSize = 0;
                    bottomBottomSize = screenH;

                    if (radioButton1.Checked) //bottom right
                    {
                        bottomLeftSize = (screenW - btmsW) - blackbar;
                        bottomTopSize = screenH - btmsH;
                    }
                    else if (radioButton2.Checked) //top right
                    {
                        bottomLeftSize = (screenW - btmsW) - blackbar;
                        bottomBottomSize = btmsH;
                    }
                    else if (radioButton3.Checked) //bottom left
                    {
                        bottomLeftSize = blackbar;
                        bottomTopSize = screenH - btmsH;
                        bottomRightSize = blackbar + btmsW;
                    }
                    else if (radioButton4.Checked) //top left
                    {
                        bottomLeftSize = blackbar;
                        bottomRightSize = blackbar + btmsW;
                        bottomBottomSize = btmsH;
                    }

                    richTextBox1.AppendText("custom_layout\\default=false\r\n");
                    richTextBox1.AppendText("custom_layout=true\r\n");
                    AppendLineWithDefaultFlag("custom_top_left", blackbar.ToString());
                    AppendLineWithDefaultFlag("custom_top_top", "0");
                    AppendLineWithDefaultFlag("custom_top_right", screenRightSize.ToString());
                    AppendLineWithDefaultFlag("custom_top_bottom", screenH.ToString());
                    AppendLineWithDefaultFlag("custom_bottom_left", bottomLeftSize.ToString());
                    AppendLineWithDefaultFlag("custom_bottom_top", bottomTopSize.ToString());
                    AppendLineWithDefaultFlag("custom_bottom_right", bottomRightSize.ToString());
                    AppendLineWithDefaultFlag("custom_bottom_bottom", bottomBottomSize.ToString());
                }
            }
            else // Default
            {
                newWidth = (float)screenW / aspectRatio.Width;
                newHeight = (float)screenH / aspectRatio.Height;
                if (newWidth == newHeight)
                {
                    blackbar = (int)Math.Floor(newWidth) / 2;
                    screenRightSize = screenW - blackbar;
                    bottomLeftSize = 0;
                    bottomRightSize = screenRightSize;
                    bottomTopSize = 0;
                    bottomBottomSize = screenH;

                    if (radioButton1.Checked) //bottom right
                    {
                        bottomLeftSize = (screenW - btmsW) - blackbar;
                        bottomTopSize = screenH - btmsH;
                    }
                    else if (radioButton2.Checked) //top right
                    {
                        bottomLeftSize = (screenW - btmsW) - blackbar;
                        bottomBottomSize = btmsH;
                    }
                    else if (radioButton3.Checked) //bottom left
                    {
                        bottomLeftSize = blackbar;
                        bottomTopSize = screenH - btmsH;
                        bottomRightSize = blackbar + btmsW;
                    }
                    else if (radioButton4.Checked) //top left
                    {
                        bottomLeftSize = blackbar;
                        bottomRightSize = blackbar + btmsW;
                        bottomBottomSize = btmsH;
                    }

                    richTextBox1.AppendText("custom_layout\\default=false\r\n");
                    richTextBox1.AppendText("custom_layout=true\r\n");
                    AppendLineWithDefaultFlag("custom_top_left", blackbar.ToString());
                    AppendLineWithDefaultFlag("custom_top_top", "0");
                    AppendLineWithDefaultFlag("custom_top_right", screenRightSize.ToString());
                    AppendLineWithDefaultFlag("custom_top_bottom", screenH.ToString());
                    AppendLineWithDefaultFlag("custom_bottom_left", bottomLeftSize.ToString());
                    AppendLineWithDefaultFlag("custom_bottom_top", bottomTopSize.ToString());
                    AppendLineWithDefaultFlag("custom_bottom_right", bottomRightSize.ToString());
                    AppendLineWithDefaultFlag("custom_bottom_bottom", bottomBottomSize.ToString());
                }
            }
        }

        private void AppendLineWithDefaultFlag(string label, string value)
        {
            bool isDefault;
            if (int.TryParse(value, out int intValue))
            {
                isDefault = intValue == 0;
            }
            else
            {
                // Handle parsing error if necessary
                isDefault = false;
            }

            string defaultFlag = isDefault ? "false" : "true"; // Invert the boolean value for the default flag
            richTextBox1.AppendText($"{label}\\default={defaultFlag}\r\n");
            richTextBox1.AppendText($"{label}={value}\r\n");
        }

        // Define a class to hold aspect ratio configurations
        public class AspectRatioConfiguration
        {
            public int Width { get; set; }
            public int Height { get; set; }

            public AspectRatioConfiguration(int width, int height)
            {
                Width = width;
                Height = height;
            }
        }

        // "resize to center" checkbox function
        private void InsetCenter()
        {
            if (checkBox1.Checked)
            {
                if (richTextBox1.Text.Length == 0)
                {
                    MessageBox.Show("There are no values available in the textbox to calculate for the centered in set method!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                int[] coordinateValues = GetCoordinateValuesFromTextBox();
                if (coordinateValues.Length != 8)
                {
                    MessageBox.Show("Error while trying to get the values from textbox! Do you have all 8 required values?", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                int[] updatedTopCoordinates = CalculateUpdatedCoordinates(coordinateValues);
                UpdateRichTextBox(updatedTopCoordinates);
            }
        }

        //helper functions for InsetCenter()
        private int[] GetCoordinateValuesFromTextBox()
        {
            List<int> values = new List<int>();

            string[] richTextBoxLines = richTextBox1.Lines;
            foreach (string line in richTextBoxLines)
            {
                if (Regex.IsMatch(line, @"=\d"))
                {
                    string numberOnly = Regex.Replace(line, @"[^\d]", "");
                    if (Int32.TryParse(numberOnly, out int numToAdd))
                    {
                        values.Add(numToAdd);
                    }
                }
            }

            return values.ToArray();
        }

        private int[] CalculateUpdatedCoordinates(int[] coordinateValues)
        {
            int[] updatedCoordinates = new int[coordinateValues.Length];
            Array.Copy(coordinateValues, updatedCoordinates, coordinateValues.Length);
            int scrHeight = GetIntegerInput(textBox6);
            int bottomScrHeight = GetIntegerInput(textBox4);

            int custom_top_top = (scrHeight / 2) / 2;
            int custom_top_bottom = custom_top_top * 2;

            updatedCoordinates[1] = custom_top_top;
            updatedCoordinates[3] = custom_top_bottom;

            if (radioButton1.Checked) //bottom right
            {
                updatedCoordinates[5] = (custom_top_top + custom_top_bottom) - bottomScrHeight;
                updatedCoordinates[7] = updatedCoordinates[5] + bottomScrHeight;
            }
            else if (radioButton2.Checked) //top right
            {
                updatedCoordinates[5] = custom_top_top;
                updatedCoordinates[7] = updatedCoordinates[5] + bottomScrHeight;
            }
            else if (radioButton3.Checked) //bottom left
            {
                updatedCoordinates[5] = (custom_top_top + custom_top_bottom) - bottomScrHeight;
                updatedCoordinates[7] = updatedCoordinates[5] + bottomScrHeight;
            }
            else if (radioButton4.Checked) //top left
            {
                updatedCoordinates[5] = custom_top_top;
                updatedCoordinates[7] = updatedCoordinates[5] + bottomScrHeight;
            }

            return updatedCoordinates;
        }

        private void UpdateRichTextBox(int[] updatedCoordinates)
        {
            richTextBox1.Clear();
            richTextBox1.AppendText("custom_layout\\default=false\r\n");
            richTextBox1.AppendText("custom_layout=true\r\n");

            string[] propertyNames = {
            "custom_top_left", "custom_top_top", "custom_top_right", "custom_top_bottom",
            "custom_bottom_left", "custom_bottom_top", "custom_bottom_right", "custom_bottom_bottom"
             };

            for (int i = 0; i < propertyNames.Length; i++)
            {
                richTextBox1.AppendText(propertyNames[i] + "\\default=" + (updatedCoordinates[i] == 0 ? "true" : "false") + "\r\n");
                richTextBox1.AppendText(propertyNames[i] + "=" + updatedCoordinates[i] + "\r\n");
            }
        }

        private void button4_Click(object sender, EventArgs e) // "calculate recommended size"
        {
            //TODO: simplify all this
            //screen resolution
            int screenW = GetIntegerInput(textBox5);
            int screenH = GetIntegerInput(textBox6);

            if (radioButton5.Checked == true) //centered
            {
                //restore default values
                int topsW = topScrWidthDef;
                int topsH = topScrHeightDef;
                int btmsW = bottomScrWidthDef;
                int btmsH = bottomScrHeightDef;

                textBox1.Text = topsW.ToString();
                textBox2.Text = topsH.ToString();
                textBox3.Text = btmsW.ToString();
                textBox4.Text = btmsH.ToString();

                //calculate height of two screens first
                float calculatedHeightMultiplier = screenH / (float)(topsH + btmsH);
                int calculatedHeightMultiplier_final = (int)Math.Floor(calculatedHeightMultiplier);
                int topScreenHeight = topsH * calculatedHeightMultiplier_final;
                int bottomScreenHeight = btmsH * calculatedHeightMultiplier_final;

                int calculatedHeightMultiplier2 = (int)Math.Ceiling(calculatedHeightMultiplier);
                float remainderOfMultiplier = calculatedHeightMultiplier2 - (float)calculatedHeightMultiplier;

                //for debugging only
                //MessageBox.Show(calculatedHeightMultiplier.ToString());
                //MessageBox.Show(calculatedHeightMultiplier2.ToString());
                //MessageBox.Show(remainderOfMultiplier.ToString());

                if (remainderOfMultiplier > 0.34 && remainderOfMultiplier < 0.5 && remainderOfMultiplier != 0 && screenW <= 1920) // top screen can be 2x bigger, bottom screen has to remain unchanged
                {
                    int topScreenWidth1 = topsW * 2; //2x
                    textBox1.Text = topScreenWidth1.ToString();

                    topScreenHeight = topsH * 2; //2x
                    textBox2.Text = topScreenHeight.ToString();
                }
                else if (remainderOfMultiplier == 0.5 && remainderOfMultiplier != 0 && screenW <= 1920) //top screen can be 1.5x bigger
                {
                    double topScreenWidth1 = topsW + (topsW * 0.5); //1.5x
                    textBox1.Text = topScreenWidth1.ToString();

                    double topScreenHeight1 = topsH + (topsH * 0.5); //1.5x
                    topScreenHeight = (int)topScreenHeight1;
                    textBox2.Text = topScreenHeight.ToString();
                }
                else if (remainderOfMultiplier <= 0.34 && remainderOfMultiplier != 0 && screenW <= 1920) //1.5x for both?
                {
                    double topScreenWidth1 = topsW + (topsW * 0.5); //1.5x
                    textBox1.Text = topScreenWidth1.ToString();

                    double topScreenHeight1 = topsH + (topsH * 0.5); //1.5x
                    topScreenHeight = (int)topScreenHeight1;
                    textBox2.Text = topScreenHeight.ToString();

                    double bottomScreenWidth1 = btmsW + (btmsW * 0.5); //1.5x
                    textBox3.Text = bottomScreenWidth1.ToString();

                    double bottomScreenHeight1 = btmsH + (btmsH * 0.5); //1.5x
                    bottomScreenHeight = (int)bottomScreenHeight1;
                    textBox4.Text = bottomScreenHeight.ToString();
                }
                else
                {
                    //double topScreenWidth2 = topScreenHeight * 1.666666666666667; //400 / 240
                    double topScreenWidth2 = topScreenHeight * (topScrWidthDef / topScrHeightDef);
                    int topScreenWidthFin = (int)Math.Round(topScreenWidth2);
                    textBox1.Text = topScreenWidthFin.ToString();

                    //double bottomScreenWidth2 = bottomScreenHeight * 1.333333333333333; //320 / 240
                    double bottomScreenWidth2 = bottomScreenHeight * (bottomScrWidthDef / bottomScrHeightDef);
                    int bottomScreenWidthFin = (int)Math.Round(bottomScreenWidth2);
                    textBox3.Text = bottomScreenWidthFin.ToString();
                }

                textBox2.Text = topScreenHeight.ToString();
                textBox4.Text = bottomScreenHeight.ToString();

                if(topScreenHeight + bottomScreenHeight == screenH) //step back one for bottom screen
                {
                    string bottomScreenWidth2 = textBox3.Text;
                    int bottomScrW = int.Parse(bottomScreenWidth2) - bottomScrWidthDef;
                    textBox3.Text = bottomScrW.ToString();

                    string bottomScreenHeight2 = textBox4.Text;
                    int bottomScrH = int.Parse(bottomScreenHeight2) - bottomScrHeightDef;
                    textBox4.Text = bottomScrH.ToString();
                }

                //
                //for uneven screen resolutions where width can be bigger
                //

                //width is the deciding factor, which is to be computed first
                float calculatedWidthMultiplier = screenW / (float)(topsW + btmsW);
                int calculatedWidthMultiplier_final = (int)Math.Floor(calculatedWidthMultiplier);
                int topScreenWidth = topsW * calculatedWidthMultiplier_final;
                int bottomScreenWidth = btmsW * calculatedWidthMultiplier_final;
                topScreenHeight = topsH * calculatedWidthMultiplier_final;
                bottomScreenHeight = btmsH * calculatedWidthMultiplier_final;

                int calculatedWidthMultiplier2 = (int)Math.Ceiling(calculatedWidthMultiplier);
                remainderOfMultiplier = calculatedWidthMultiplier2 - (float)calculatedWidthMultiplier;

                if (remainderOfMultiplier < 0.32 && remainderOfMultiplier != 0 && screenW <= 1920)
                {
                    //1.5x
                    double topScreenWidth1 = topsW + (topsW * 0.5); //1.5x
                    topScreenWidth = (int)topScreenWidth1;
                    textBox1.Text = topScreenWidth.ToString();

                    double bottomScreenWidth1 = btmsW + (btmsW * 0.5); //1.5x
                    bottomScreenWidth = (int)bottomScreenWidth1;
                    textBox3.Text = bottomScreenWidth.ToString();
                }
                else if (remainderOfMultiplier > 0.10 && remainderOfMultiplier != 0)
                {

                    if (topScreenWidth + topScrWidthDef < bottomScreenWidth)
                    {
                        topScreenWidth += topScrWidthDef;
                    }
                    textBox1.Text = topScreenWidth.ToString();

                    if (btmsW != bottomScrWidthDef)
                    {
                        double bottomScreenWidth1 = btmsW + (btmsW * 0.5); //1.5x
                        bottomScreenWidth = (int)bottomScreenWidth1;
                    }
                    textBox3.Text = bottomScreenWidth.ToString();
                }

                if (topScreenWidth + bottomScreenWidth >= screenW)  //step back one for bottom screen
                {
                    string bottomScreenW = textBox3.Text;
                    int bottomScrW = int.Parse(bottomScreenW) - bottomScrWidthDef;
                    textBox3.Text = bottomScrW.ToString();
                }

                //fix too much height
                if (bottomScreenHeight >= screenH)
                {
                    string bottomScreenH = textBox4.Text;
                    int bottomScrH = (int.Parse(bottomScreenH) - screenH) * 2;
                    bottomScreenHeight -= bottomScrH;
                    textBox4.Text = bottomScreenHeight.ToString();
                }

            }

            if (radioButton6.Checked == true) //side-by-side
            {
                //restore default values
                int topsW = topScrWidthDef;
                int topsH = topScrHeightDef;
                int btmsW = bottomScrWidthDef;
                int btmsH = bottomScrHeightDef;

                textBox1.Text = topsW.ToString();
                textBox2.Text = topsH.ToString();
                textBox3.Text = btmsW.ToString();
                textBox4.Text = btmsH.ToString();

                //width is the deciding factor, which is to be computed first
                float calculatedWidthMultiplier = screenW / (float)(topsW + btmsW);
                int calculatedWidthMultiplier_final = (int)Math.Floor(calculatedWidthMultiplier);
                int topScreenWidth = topsW * calculatedWidthMultiplier_final;
                int bottomScreenWidth = btmsW * calculatedWidthMultiplier_final;
                int topScreenHeight = topsH * calculatedWidthMultiplier_final;
                int bottomScreenHeight = btmsH * calculatedWidthMultiplier_final;

                int calculatedWidthMultiplier2 = (int)Math.Ceiling(calculatedWidthMultiplier);
                float remainderOfMultiplier = calculatedWidthMultiplier2 - (float)calculatedWidthMultiplier;

                //for debugging only
                //MessageBox.Show(calculatedWidthMultiplier.ToString());
                //MessageBox.Show(calculatedWidthMultiplier2.ToString());
                //MessageBox.Show(remainderOfMultiplier.ToString());

                if (remainderOfMultiplier < 0.32 && remainderOfMultiplier != 0 && screenW <= 1920)
                {
                    //1.5x
                    double topScreenWidth1 = topsW + (topsW * 0.5); //1.5x
                    topScreenWidth = (int)topScreenWidth1;
                    textBox1.Text = topScreenWidth.ToString();

                    double topScreenHeight1 = topsH + (topsH * 0.5); //1.5x
                    topScreenHeight = (int)topScreenHeight1;
                    textBox2.Text = topScreenHeight.ToString();

                    double bottomScreenWidth1 = btmsW + (btmsW * 0.5); //1.5x
                    bottomScreenWidth = (int)bottomScreenWidth1;
                    textBox3.Text = bottomScreenWidth.ToString();

                    double bottomScreenHeight1 = btmsH + (btmsH * 0.5); //1.5x
                    bottomScreenHeight = (int)bottomScreenHeight1;
                    textBox4.Text = bottomScreenHeight.ToString();
                } else if (remainderOfMultiplier > 0.10 && remainderOfMultiplier != 0)
                {

                    if(topScreenWidth + topScrWidthDef < bottomScreenWidth)
                    {
                        topScreenWidth += topScrWidthDef;
                    }

                    if(topScreenHeight + topScrHeightDef < bottomScreenHeight)
                    {
                        topScreenHeight += topScrHeightDef;
                    }

                    textBox1.Text = topScreenWidth.ToString();
                    textBox2.Text = topScreenHeight.ToString();

                    if(btmsW != bottomScrWidthDef)
                    {
                        double bottomScreenWidth1 = btmsW + (btmsW * 0.5); //1.5x
                        bottomScreenWidth = (int)bottomScreenWidth1;
                    }
                    textBox3.Text = bottomScreenWidth.ToString();

                    if(btmsH != bottomScrHeightDef)
                    {
                        double bottomScreenHeight1 = btmsH + (btmsH * 0.5); //1.5x
                        bottomScreenHeight = (int)bottomScreenHeight1;
                    }
                    textBox4.Text = bottomScreenHeight.ToString();

                    //textBox1.Text = topScreenWidth.ToString();
                    //textBox2.Text = topScreenHeight.ToString();
                    //textBox3.Text = bottomScreenWidth.ToString();
                    //textBox4.Text = bottomScreenHeight.ToString();
                }

                if(topScreenWidth + bottomScreenWidth >= screenW)  //step back one for bottom screen
                {
                    string bottomScreenW = textBox3.Text;
                    int bottomScrW = int.Parse(bottomScreenW) - bottomScrWidthDef;
                    textBox3.Text = bottomScrW.ToString();

                    string bottomScreenH = textBox4.Text;
                    int bottomScrH = int.Parse(bottomScreenH) - bottomScrHeightDef;
                    textBox4.Text = bottomScrH.ToString();
                }

                //fix too much height
                if(topScreenHeight >= screenH)
                {
                    string topScreenH = textBox2.Text;
                    int topScrH = (int.Parse(topScreenH) - screenH) * 2;
                    topScreenHeight -= topScrH;
                    textBox2.Text = topScreenHeight.ToString();
                }

                if (bottomScreenHeight >= screenH)
                {
                    string bottomScreenH = textBox4.Text;
                    int bottomScrH = (int.Parse(bottomScreenH) - screenH) * 2;
                    bottomScreenHeight -= bottomScrH;
                    textBox4.Text = bottomScreenHeight.ToString();
                }

                //
                //for uneven screen resolutions where height can be bigger
                //

                //calculate height of two screens
                float calculatedHeightMultiplier = screenH / (float)(topsH + btmsH);
                int calculatedHeightMultiplier_final = (int)Math.Floor(calculatedHeightMultiplier);
                topScreenHeight = topsH * calculatedHeightMultiplier_final;
                bottomScreenHeight = btmsH * calculatedHeightMultiplier_final;

                int calculatedHeightMultiplier2 = (int)Math.Ceiling(calculatedHeightMultiplier);
                remainderOfMultiplier = calculatedHeightMultiplier2 - (float)calculatedHeightMultiplier;

                //for debugging only
                //MessageBox.Show(calculatedHeightMultiplier.ToString());
                //MessageBox.Show(calculatedHeightMultiplier2.ToString());
                //MessageBox.Show(remainderOfMultiplier.ToString());

                if (remainderOfMultiplier > 0.34 && remainderOfMultiplier < 0.5 && remainderOfMultiplier != 0 && screenW <= 1920) // top screen can be 2x bigger, bottom screen has to remain unchanged
                {
                    topScreenHeight = topsH * 2; //2x
                    textBox2.Text = topScreenHeight.ToString();
                }
                else if (remainderOfMultiplier == 0.5 && remainderOfMultiplier != 0 && screenW <= 1920) //top screen can be 1.5x bigger
                {
                    double topScreenHeight1 = topsH + (topsH * 0.5); //1.5x
                    topScreenHeight = (int)topScreenHeight1;
                    textBox2.Text = topScreenHeight.ToString();
                }
                else if (remainderOfMultiplier <= 0.34 && remainderOfMultiplier != 0 && screenW <= 1920) //1.5x for both?
                {
                    double topScreenHeight1 = topsH + (topsH * 0.5); //1.5x
                    topScreenHeight = (int)topScreenHeight1;
                    textBox2.Text = topScreenHeight.ToString();

                    double bottomScreenHeight1 = btmsH + (btmsH * 0.5); //1.5x
                    bottomScreenHeight = (int)bottomScreenHeight1;
                    textBox4.Text = bottomScreenHeight.ToString();
                }

                textBox2.Text = topScreenHeight.ToString();
                textBox4.Text = bottomScreenHeight.ToString();

                if (topScreenHeight + bottomScreenHeight == screenH) //step back one for bottom screen
                {
                    string bottomScreenHeight2 = textBox4.Text;
                    int bottomScrH = int.Parse(bottomScreenHeight2) - bottomScrHeightDef;
                    textBox4.Text = bottomScrH.ToString();
                }
            }
        }

        // copy richtextbox's contents into the clipboard with a single right click of the mouse
        private void richTextBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                richTextBox1.SelectAll();
                try
                {
                    Clipboard.SetText(richTextBox1.SelectedText);
                }
                catch (ArgumentNullException)
                {
                    MessageBox.Show("Nothing is selected here or nothing can be selected.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                catch (ExternalException)
                {
                    MessageBox.Show("Error while handling the clipboard!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e) // "generate preview image..."
        {
            try
            {
                int screenW = GetIntegerInput(textBox5);
                int screenH = GetIntegerInput(textBox6);
                int topsW = GetIntegerInput(textBox1);
                int topsH = GetIntegerInput(textBox2);
                int btmsW = GetIntegerInput(textBox3);
                int btmsH = GetIntegerInput(textBox4);
                int screenSep = GetEvenIntegerInput(textBox7);
                int[] coordinateValues = GetCoordinateValues(richTextBox1);

                int custom_top_left = coordinateValues[0];
                int custom_top_top = coordinateValues[1];
                int custom_top_right = coordinateValues[2];
                int custom_top_bottom = coordinateValues[3];
                int custom_bottom_left = coordinateValues[4];
                int custom_bottom_top = coordinateValues[5];

                Bitmap bitmap = new Bitmap(screenW, screenH, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
                using (Graphics g = Graphics.FromImage(bitmap))
                {
                    using (System.Drawing.SolidBrush blackBrush = new System.Drawing.SolidBrush(System.Drawing.Color.Black))
                    {
                        g.FillRectangle(blackBrush, new Rectangle(0, 0, screenW, screenH));
                    }

                    if (radioButton7.Checked || radioButton9.Checked)
                    {
                        DrawScreens(g, custom_top_left, custom_top_top, topsW, topsH, custom_bottom_left, custom_bottom_top, btmsW, btmsH, screenSep, custom_top_left, custom_top_right, custom_top_bottom, custom_bottom_top);
                    }
                }

                bitmap.Save(screenW + "x" + screenH + ".jpg");
                MessageBox.Show("Image saved as: " + screenW + "x" + screenH + ".jpg", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception)
            {
                MessageBox.Show("An error occurred.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button6_Click(object sender, EventArgs e) // "edit qt-config.ini"
        {
            string config_path = textBox8.Text;

            if(string.IsNullOrWhiteSpace(config_path))
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(richTextBox1.Text))
            {
                MessageBox.Show("There are no values available in the textbox to edit the config!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!File.Exists(config_path))
            {
                MessageBox.Show("File: \"" + config_path + "\" does not exist!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            INIFile inif = new INIFile(config_path);
            string[] RichTextBoxLines = richTextBox1.Lines;

            foreach (string line in RichTextBoxLines)
            {
                if (string.IsNullOrWhiteSpace(line))
                {
                    continue;
                }

                try
                {
                    string stringOnly = Regex.Replace(line, @"\=.*$", "");
                    string valueOnly = Regex.Replace(line, @".*=(.*)", "$1");

                    string[] layoutOptions = {
                    "custom_layout", "custom_top_left", "custom_top_top",
                    "custom_top_right", "custom_top_bottom", "custom_bottom_left",
                    "custom_bottom_top", "custom_bottom_right", "custom_bottom_bottom"
                    };

                    foreach (string layoutOption in layoutOptions)
                    {
                        if (stringOnly == layoutOption || stringOnly == layoutOption + "\\default")
                        {
                            inif.Write("Layout", stringOnly, valueOnly);
                            break;
                        }
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("There was an error trying to update this file: " + config_path, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            MessageBox.Show("This file has been updated with the textbox's values: " + config_path, "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        //helper functions
        private int GetIntegerInput(TextBox textBox)
        {
            if (!int.TryParse(textBox.Text, out int value))
            {
                //throw new Exception("Value: " + textBox.Text + " is not an integer!");
                MessageBox.Show("Value: \"" + textBox.Text.ToString() + "\" is not an integer!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return 0;
            }
            return value;
        }

        private int GetEvenIntegerInput(TextBox textBox)
        {
            int value = GetIntegerInput(textBox);
            if (value % 2 != 0)
            {
                MessageBox.Show("Value: " + value + " is an odd number! Incrementing by 1...", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                value++;
            }
            return value;
        }

        private bool ValidateIntegerInput(TextBox textBox, out int value)
        {
            if (int.TryParse(textBox.Text, out value))
            {
                return true;
            }
            MessageBox.Show($"Value: {textBox.Text} is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return false;
        }

        private bool ValidateEvenIntegerInput(TextBox textBox, out int value)
        {
            if (ValidateIntegerInput(textBox, out value))
            {
                if (value % 2 != 0)
                {
                    MessageBox.Show($"Value: {value} is an odd number! Incrementing by 1...", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    value++;
                }
                return true;
            }
            return false;
        }

        private bool ValidateWidth(int value, int screenWidth, string label)
        {
            if (value > screenWidth)
            {
                MessageBox.Show($"The {label} is bigger than the screen resolution's width!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private bool ValidateTopHeight(int topHeight, int bottomHeight, int screenHeight)
        {
            if (topHeight + bottomHeight > screenHeight)
            {
                MessageBox.Show("The top screen and bottom screen cannot fit into this screen resolution (considering height)!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void ValidateInputs()
        {
            int screenWidth = GetIntegerInput(textBox5);
            int screenHeight = GetIntegerInput(textBox6);
            int topWidth = GetIntegerInput(textBox1);
            int topHeight = GetIntegerInput(textBox2);
            int bottomWidth = GetIntegerInput(textBox3);
            int bottomHeight = GetIntegerInput(textBox4);
            int screenSeparator = ValidateEvenIntegerInput(textBox7, out int separatorValue) ? separatorValue : -1;

            if (screenWidth == -1 || screenHeight == -1 || topWidth == -1 || topHeight == -1 || bottomWidth == -1 || bottomHeight == -1 || screenSeparator == -1)
            {
                return;
            }

            if (!ValidateWidth(topWidth, screenWidth, "Top Screen Width") ||
                !ValidateWidth(bottomWidth, screenWidth, "Bottom Screen Width") ||
                !ValidateTopHeight(topHeight, bottomHeight, screenHeight))
            {
                return;
            }
        }

        private int[] GetCoordinateValues(RichTextBox richTextBox)
        {
            string[] lines = richTextBox.Lines;
            int[] coordinateValues = new int[8];
            int index = 0;

            foreach (string line in lines)
            {
                if (Regex.IsMatch(line, @"=\d"))
                {
                    string numberOnly = Regex.Replace(line, @"[^\d]", "");
                    if (int.TryParse(numberOnly, out int numToAdd))
                    {
                        coordinateValues[index] = numToAdd;
                        index++;
                    }
                }
            }

            if (index < 8)
            {
                throw new Exception("Error while trying to get the values from textbox! Do you have all 8 required values?");
            }

            return coordinateValues;
        }

        private void DrawScreens(Graphics g, int topLeftX, int topLeftY, int topWidth, int topHeight,
            int bottomLeftX, int bottomTopY, int bottomWidth, int bottomHeight, int screenSep,
            int custom_top_left = 0, int custom_top_right = 0, int custom_top_bottom = 0, int custom_bottom_top = 0)
        {
            using (System.Drawing.SolidBrush redBrush = new System.Drawing.SolidBrush(System.Drawing.Color.Red))
            using (System.Drawing.SolidBrush blueBrush = new System.Drawing.SolidBrush(System.Drawing.Color.Blue))
            {
                if (radioButton7.Checked)
                {
                    g.FillRectangle(redBrush, new Rectangle(topLeftX, topLeftY, topWidth, topHeight));
                    g.FillRectangle(blueBrush, new Rectangle(bottomLeftX, (bottomTopY - screenSep) + screenSep, bottomWidth, bottomHeight));
                }
                else if (radioButton9.Checked)
                {
                    g.FillRectangle(redBrush, new Rectangle(topLeftX, topLeftY, custom_top_right - custom_top_left, custom_top_bottom));
                    g.FillRectangle(blueBrush, new Rectangle(bottomLeftX, (custom_bottom_top - screenSep) + screenSep, bottomWidth, bottomHeight));
                }
            }
        }

        // to be able to manipulate INI files
        class INIFile
        {
            private string filePath;

            [DllImport("kernel32")]
            private static extern long WritePrivateProfileString(string section,
            string key,
            string val,
            string filePath);

            [DllImport("kernel32")]
            private static extern int GetPrivateProfileString(string section,
            string key,
            string def,
            StringBuilder retVal,
            int size,
            string filePath);

            public INIFile(string filePath)
            {
                this.filePath = filePath;
            }

            public void Write(string section, string key, string value)
            {
                WritePrivateProfileString(section, key, value.ToLower(), this.filePath);
            }

            public string Read(string section, string key)
            {
                StringBuilder SB = new StringBuilder(255);
                int i = GetPrivateProfileString(section, key, "", SB, 255, this.filePath);
                return SB.ToString();
            }

            public string FilePath
            {
                get { return this.filePath; }
                set { this.filePath = value; }
            }
        }

    }
}
