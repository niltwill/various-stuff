﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Citra_LayoutGenerator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox8.Text = "C:\\Users\\" + Environment.UserName + "\\AppData\\Roaming\\Citra\\config\\qt-config.ini";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<TextBox> textBoxes = new List<TextBox> { textBox5, textBox6, textBox1, textBox2, textBox3, textBox4, textBox7 };
            List<string> labels = new List<string> { "Screen Width", "Screen Height", "Top Screen Width", "Top Screen Height", "Bottom Screen Width", "Bottom Screen Height", "Screen Separator" };

            for (int i = 0; i < textBoxes.Count; i++)
            {
                var textBox = textBoxes[i];
                var label = labels[i];

                if (!int.TryParse(textBox.Text, out int value))
                {
                    MessageBox.Show($"Value: {textBox.Text} is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                switch (label)
                {
                    case "Screen Separator":
                        if (value % 2 != 0)
                        {
                            MessageBox.Show($"Value: {textBox.Text} is an odd number! Incrementing by 1...", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            value += 1;
                        }
                        break;
                    case "Top Screen Height":
                        if (value + int.Parse(textBox4.Text) > int.Parse(textBox6.Text))
                        {
                            MessageBox.Show("The top screen and bottom screen cannot fit into this screen resolution (considering height)!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        break;
                    case "Top Screen Width":
                    case "Bottom Screen Width":
                        if (value > int.Parse(textBox5.Text))
                        {
                            MessageBox.Show($"The {label} is bigger than the screen resolution's width!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        break;
                }
            }

            int screenSep = int.Parse(textBox7.Text);
            int screenSep2 = screenSep / 2;
            int screenW = int.Parse(textBox5.Text);
            int screenH = int.Parse(textBox6.Text);
            int topsW = int.Parse(textBox1.Text);
            int topsH = int.Parse(textBox2.Text);
            int btmsW = int.Parse(textBox3.Text);
            int btmsH = int.Parse(textBox4.Text);

            richTextBox1.Clear();

            int topScreenLeftRight = (screenW - topsW) / 2;
            int screenUpDownSize = (screenH - topsH - btmsH) / 2 - screenSep2;
            int topRightSize = topScreenLeftRight + topsW;
            int topBottomSize = screenUpDownSize + topsH;

            int bottomScreenLeftRight = (screenW - btmsW) / 2;
            int bottomTopSize = topBottomSize + screenSep;
            int bottomRightSize = bottomScreenLeftRight + btmsW;
            int bottomBottomSize = screenH - screenUpDownSize;

            if (topScreenLeftRight < 0 || screenUpDownSize < 0 || topRightSize < 0 || topBottomSize < 0
                || bottomScreenLeftRight < 0 || bottomTopSize < 0 || bottomRightSize < 0 || bottomBottomSize < 0)
            {
                MessageBox.Show("At least one of the calculated values was negative! Check if the screen resolutions are optimized properly.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string[] layoutLines = {
                "custom_layout\\default=false",
                "custom_layout=true",
                "custom_top_left\\default=false",
                $"custom_top_left={topScreenLeftRight}",
                "custom_top_top\\default=false",
                $"custom_top_top={screenUpDownSize}",
                "custom_top_right\\default=false",
                $"custom_top_right={topRightSize}",
                "custom_top_bottom\\default=false",
                $"custom_top_bottom={topBottomSize}",
                "custom_bottom_left\\default=false",
                $"custom_bottom_left={bottomScreenLeftRight}",
                "custom_bottom_top\\default=false",
                $"custom_bottom_top={bottomTopSize}",
                "custom_bottom_right\\default=false",
                $"custom_bottom_right={bottomRightSize}",
                "custom_bottom_bottom\\default=false",
                $"custom_bottom_bottom={bottomBottomSize}"
            };

            richTextBox1.Lines = layoutLines;

            //MessageBox.Show("Layout values calculated and added to the textbox!", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            List<TextBox> textBoxes = new List<TextBox> { textBox5, textBox6, textBox1, textBox2, textBox3, textBox4, textBox7 };
            List<string> labels = new List<string> { "Screen Width", "Screen Height", "Top Screen Width", "Top Screen Height", "Bottom Screen Width", "Bottom Screen Height", "Screen Separator" };

            for (int i = 0; i < textBoxes.Count; i++)
            {
                var textBox = textBoxes[i];
                var label = labels[i];

                if (!int.TryParse(textBox.Text, out int value))
                {
                    MessageBox.Show($"Value: {textBox.Text} is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                switch (label)
                {
                    case "Screen Separator":
                        if (value % 2 != 0)
                        {
                            MessageBox.Show($"Value: {textBox.Text} is an odd number! Incrementing by 1...", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            value += 1;
                        }
                        break;
                }
            }

            int screenW = int.Parse(textBox5.Text);
            int screenH = int.Parse(textBox6.Text);
            int topsW = int.Parse(textBox1.Text);
            int topsH = int.Parse(textBox2.Text);
            int btmsW = int.Parse(textBox3.Text);
            int btmsH = int.Parse(textBox4.Text);
            int screenSep = int.Parse(textBox7.Text);
            int screenSep2 = screenSep / 2;

            richTextBox1.Clear();

            int topScreenLeftRight = (screenW - (topsW + btmsW)) / 2 - screenSep2;
            int screenUpDownSize = (screenH - topsH) / 2;
            int topRightSize = topScreenLeftRight + topsW;
            int topBottomSize = screenUpDownSize + topsH;

            int bottomScreenLeftRight = topRightSize + screenSep;
            int bottomTopSize = (screenH - btmsH) / 2;
            int bottomRightSize = screenW - topScreenLeftRight;
            int bottomBottomSize = bottomTopSize + btmsH;

            if (topScreenLeftRight < 0 || screenUpDownSize < 0 || topRightSize < 0 || topBottomSize < 0
                || bottomScreenLeftRight < 0 || bottomTopSize < 0 || bottomRightSize < 0 || bottomBottomSize < 0)
            {
                MessageBox.Show("At least one of the calculated values was in minus! Check if the screen resolutions are optimized properly.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string[] layoutLines = {
                "custom_layout\\default=false",
                "custom_layout=true",
                "custom_top_left\\default=false",
                $"custom_top_left={topScreenLeftRight}",
                "custom_top_top\\default=false",
                $"custom_top_top={screenUpDownSize}",
                "custom_top_right\\default=false",
                $"custom_top_right={topRightSize}",
                "custom_top_bottom\\default=false",
                $"custom_top_bottom={topBottomSize}",
                "custom_bottom_left\\default=false",
                $"custom_bottom_left={bottomScreenLeftRight}",
                "custom_bottom_top\\default=false",
                $"custom_bottom_top={bottomTopSize}",
                "custom_bottom_right\\default=false",
                $"custom_bottom_right={bottomRightSize}",
                "custom_bottom_bottom\\default=false",
                $"custom_bottom_bottom={bottomBottomSize}"
            };

            richTextBox1.Lines = layoutLines;

            //MessageBox.Show("Layout values calculated and added to the textbox!", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //screen resolution
            int screenW = 0;
            int screenH = 0;

            if (Int32.TryParse(textBox5.Text, out int sW))
            {
                screenW = sW;
            }
            else
            {
                MessageBox.Show("Value: " + textBox5.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (Int32.TryParse(textBox6.Text, out int sH))
            {
                screenH = sH;
            }
            else
            {
                MessageBox.Show("Value: " + textBox6.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //bottom screen
            int btmsW = 0;
            int btmsH = 0;

            if (Int32.TryParse(textBox3.Text, out int bW))
            {
                btmsW = bW;
            }
            else
            {
                MessageBox.Show("Value: " + textBox3.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (Int32.TryParse(textBox4.Text, out int bH))
            {
                btmsH = bH;
            }
            else
            {
                MessageBox.Show("Value: " + textBox4.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //check for bigger resolution errors
            if (btmsW > screenW)
            {
                MessageBox.Show("The bottom screen's width is bigger than the screen resolution's width!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //remove previous generation
            richTextBox1.Clear();

            //calculate new dimensions based on aspect ratio
            float newWidth, newHeight, dif;

            //16:9
            newWidth = (float)screenW / 16;
            newHeight = (float)screenH / 9;
            if(newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //4:3
            newWidth = (float)screenW / 4;
            newHeight = (float)screenH / 3;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //3:2
            newWidth = (float)screenW / 3;
            newHeight = (float)screenH / 2;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //5:3
            newWidth = (float)screenW / 5;
            newHeight = (float)screenH / 3;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //5:4
            newWidth = (float)screenW / 5;
            newHeight = (float)screenH / 4;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //8:5
            newWidth = (float)screenW / 8;
            newHeight = (float)screenH / 5;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //9:5
            newWidth = (float)screenW / 9;
            newHeight = (float)screenH / 5;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //21:9
            newWidth = (float)screenW / 21;
            newHeight = (float)screenH / 9;
            newWidth = (int)Math.Floor(newWidth);
            dif = newWidth - newHeight;
            newWidth = (float)newWidth - dif;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //25:11
            newWidth = (float)screenW / 25;
            newHeight = (float)screenH / 11;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //25:12
            newWidth = (float)screenW / 25;
            newHeight = (float)screenH / 12;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //25:16
            newWidth = (float)screenW / 25;
            newHeight = (float)screenH / 16;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //32:9
            newWidth = (float)screenW / 32;
            newHeight = (float)screenH / 9;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //32:10
            newWidth = (float)screenW / 32;
            newHeight = (float)screenH / 10;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //32:25
            newWidth = (float)screenW / 32;
            newHeight = (float)screenH / 25;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //1366x768
            if (screenW == 1366 && screenH == 768)
            {
                int blackbar = 214;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //screen resolution
            int screenW = 0;
            int screenH = 0;

            if (Int32.TryParse(textBox5.Text, out int sW))
            {
                screenW = sW;
            }
            else
            {
                MessageBox.Show("Value: " + textBox5.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (Int32.TryParse(textBox6.Text, out int sH))
            {
                screenH = sH;
            }
            else
            {
                MessageBox.Show("Value: " + textBox6.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (radioButton5.Checked == true) //centered
            {
                //restore default values
                int topsW = 400;
                int topsH = 240;
                int btmsW = 320;
                int btmsH = 240;

                textBox1.Text = topsW.ToString();
                textBox2.Text = topsH.ToString();
                textBox3.Text = btmsW.ToString();
                textBox4.Text = btmsH.ToString();

                //calculate height of two screens first
                float calculatedHeightMultiplier = screenH / (float)(topsH + btmsH);
                int calculatedHeightMultiplier_final = (int)Math.Floor(calculatedHeightMultiplier);
                int topScreenHeight = topsH * calculatedHeightMultiplier_final;
                int bottomScreenHeight = btmsH * calculatedHeightMultiplier_final;

                int calculatedHeightMultiplier2 = (int)Math.Ceiling(calculatedHeightMultiplier);
                float remainderOfMultiplier = calculatedHeightMultiplier2 - (float)calculatedHeightMultiplier;

                //for debugging only
                //MessageBox.Show(calculatedHeightMultiplier.ToString());
                //MessageBox.Show(calculatedHeightMultiplier2.ToString());
                //MessageBox.Show(remainderOfMultiplier.ToString());

                if (remainderOfMultiplier > 0.34 && remainderOfMultiplier < 0.5 && remainderOfMultiplier != 0 && screenW <= 1920) // top screen can be 2x bigger, bottom screen has to remain unchanged
                {
                    int topScreenWidth1 = topsW * 2; //2x
                    textBox1.Text = topScreenWidth1.ToString();

                    topScreenHeight = topsH * 2; //2x
                    textBox2.Text = topScreenHeight.ToString();
                }
                else if (remainderOfMultiplier == 0.5 && remainderOfMultiplier != 0 && screenW <= 1920) //top screen can be 1.5x bigger
                {
                    double topScreenWidth1 = topsW + (topsW * 0.5); //1.5x
                    textBox1.Text = topScreenWidth1.ToString();

                    double topScreenHeight1 = topsH + (topsH * 0.5); //1.5x
                    topScreenHeight = (int)topScreenHeight1;
                    textBox2.Text = topScreenHeight.ToString();
                }
                else if (remainderOfMultiplier <= 0.34 && remainderOfMultiplier != 0 && screenW <= 1920) //1.5x for both?
                {
                    double topScreenWidth1 = topsW + (topsW * 0.5); //1.5x
                    textBox1.Text = topScreenWidth1.ToString();

                    double topScreenHeight1 = topsH + (topsH * 0.5); //1.5x
                    topScreenHeight = (int)topScreenHeight1;
                    textBox2.Text = topScreenHeight.ToString();

                    double bottomScreenWidth1 = btmsW + (btmsW * 0.5); //1.5x
                    textBox3.Text = bottomScreenWidth1.ToString();

                    double bottomScreenHeight1 = btmsH + (btmsH * 0.5); //1.5x
                    bottomScreenHeight = (int)bottomScreenHeight1;
                    textBox4.Text = bottomScreenHeight.ToString();
                }
                else
                {
                    double topScreenWidth2 = topScreenHeight * 1.666666666666667; //400 / 240
                    int topScreenWidthFin = (int)Math.Round(topScreenWidth2);
                    textBox1.Text = topScreenWidthFin.ToString();

                    double bottomScreenWidth2 = bottomScreenHeight * 1.333333333333333; //320 / 240
                    int bottomScreenWidthFin = (int)Math.Round(bottomScreenWidth2);
                    textBox3.Text = bottomScreenWidthFin.ToString();
                }

                textBox2.Text = topScreenHeight.ToString();
                textBox4.Text = bottomScreenHeight.ToString();

                if(topScreenHeight + bottomScreenHeight == screenH) //step back one for bottom screen
                {
                    string bottomScreenWidth = textBox3.Text;
                    int bottomScrW = int.Parse(bottomScreenWidth) - 320;
                    textBox3.Text = bottomScrW.ToString();

                    string bottomScreenHeight2 = textBox4.Text;
                    int bottomScrH = int.Parse(bottomScreenHeight2) - 240;
                    textBox4.Text = bottomScrH.ToString();
                }

            }

            if (radioButton6.Checked == true) //side-by-side
            {
                //restore default values
                int topsW = 400;
                int topsH = 240;
                int btmsW = 320;
                int btmsH = 240;

                textBox1.Text = topsW.ToString();
                textBox2.Text = topsH.ToString();
                textBox3.Text = btmsW.ToString();
                textBox4.Text = btmsH.ToString();

                //width is the deciding factor, which is to be computed first
                float calculatedWidthMultiplier = screenW / (float)(topsW + btmsW);
                int calculatedWidthMultiplier_final = (int)Math.Floor(calculatedWidthMultiplier);
                int topScreenWidth = topsW * calculatedWidthMultiplier_final;
                int bottomScreenWidth = btmsW * calculatedWidthMultiplier_final;
                int topScreenHeight = topsH * calculatedWidthMultiplier_final;
                int bottomScreenHeight = btmsH * calculatedWidthMultiplier_final;

                int calculatedWidthMultiplier2 = (int)Math.Ceiling(calculatedWidthMultiplier);
                float remainderOfMultiplier = calculatedWidthMultiplier2 - (float)calculatedWidthMultiplier;

                //for debugging only
                //MessageBox.Show(calculatedWidthMultiplier.ToString());
                //MessageBox.Show(calculatedWidthMultiplier2.ToString());
                //MessageBox.Show(remainderOfMultiplier.ToString());

                if (remainderOfMultiplier < 0.32 && remainderOfMultiplier != 0 && screenW <= 1920)
                {
                    //1.5x
                    double topScreenWidth1 = topsW + (topsW * 0.5); //1.5x
                    topScreenWidth = (int)topScreenWidth1;
                    textBox1.Text = topScreenWidth.ToString();

                    double topScreenHeight1 = topsH + (topsH * 0.5); //1.5x
                    topScreenHeight = (int)topScreenHeight1;
                    textBox2.Text = topScreenHeight.ToString();

                    double bottomScreenWidth1 = btmsW + (btmsW * 0.5); //1.5x
                    bottomScreenWidth = (int)bottomScreenWidth1;
                    textBox3.Text = bottomScreenWidth.ToString();

                    double bottomScreenHeight1 = btmsH + (btmsH * 0.5); //1.5x
                    bottomScreenHeight = (int)bottomScreenHeight1;
                    textBox4.Text = bottomScreenHeight.ToString();
                } else if (remainderOfMultiplier > 0.10 && remainderOfMultiplier != 0)
                {

                    if(topScreenWidth + 400 < bottomScreenWidth)
                    {
                        topScreenWidth += 400;
                    }

                    if(topScreenHeight + 240 < bottomScreenHeight)
                    {
                        topScreenHeight += 240;
                    }

                    textBox1.Text = topScreenWidth.ToString();
                    textBox2.Text = topScreenHeight.ToString();

                    if(btmsW != 320)
                    {
                        double bottomScreenWidth1 = btmsW + (btmsW * 0.5); //1.5x
                        bottomScreenWidth = (int)bottomScreenWidth1;
                    }
                    textBox3.Text = bottomScreenWidth.ToString();

                    if(btmsH != 240)
                    {
                        double bottomScreenHeight1 = btmsH + (btmsH * 0.5); //1.5x
                        bottomScreenHeight = (int)bottomScreenHeight1;
                    }
                    textBox4.Text = bottomScreenHeight.ToString();

                    //textBox1.Text = topScreenWidth.ToString();
                    //textBox2.Text = topScreenHeight.ToString();
                    //textBox3.Text = bottomScreenWidth.ToString();
                    //textBox4.Text = bottomScreenHeight.ToString();
                }

                if(topScreenWidth + bottomScreenWidth >= screenW)  //step back one for bottom screen
                {
                    string bottomScreenW = textBox3.Text;
                    int bottomScrW = int.Parse(bottomScreenW) - 320;
                    textBox3.Text = bottomScrW.ToString();

                    string bottomScreenH = textBox4.Text;
                    int bottomScrH = int.Parse(bottomScreenH) - 240;
                    textBox4.Text = bottomScrH.ToString();
                }

                //fix too much height
                if(topScreenHeight >= screenH)
                {
                    string topScreenH = textBox2.Text;
                    int topScrH = (int.Parse(topScreenH) - screenH) * 2;
                    topScreenHeight -= topScrH;
                    textBox2.Text = topScreenHeight.ToString();
                }

                if (bottomScreenHeight >= screenH)
                {
                    string bottomScreenH = textBox4.Text;
                    int bottomScrH = (int.Parse(bottomScreenH) - screenH) * 2;
                    bottomScreenHeight -= bottomScrH;
                    textBox4.Text = bottomScreenHeight.ToString();
                }
            }
        }

        private void richTextBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                richTextBox1.SelectAll();
                try
                {
                    Clipboard.SetText(richTextBox1.SelectedText);
                }
                catch (ArgumentNullException)
                {
                    MessageBox.Show("Nothing is selected here or nothing can be selected.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                catch (Exception)
                {
                    MessageBox.Show("Error while handling the textbox!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //screen resolution
            int screenW = 0;
            int screenH = 0;

            if (Int32.TryParse(textBox5.Text, out int sW))
            {
                screenW = sW;
            }
            else
            {
                MessageBox.Show("Value: " + textBox5.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (Int32.TryParse(textBox6.Text, out int sH))
            {
                screenH = sH;
            }
            else
            {
                MessageBox.Show("Value: " + textBox6.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //top screen
            int topsW = 0;
            int topsH = 0;

            if (Int32.TryParse(textBox1.Text, out int tW))
            {
                topsW = tW;
            }
            else
            {
                MessageBox.Show("Value: " + textBox1.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (Int32.TryParse(textBox2.Text, out int tH))
            {
                topsH = tH;
            }
            else
            {
                MessageBox.Show("Value: " + textBox2.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //bottom screen
            int btmsW = 0;
            int btmsH = 0;

            if (Int32.TryParse(textBox3.Text, out int bW))
            {
                btmsW = bW;
            }
            else
            {
                MessageBox.Show("Value: " + textBox3.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (Int32.TryParse(textBox4.Text, out int bH))
            {
                btmsH = bH;
            }
            else
            {
                MessageBox.Show("Value: " + textBox4.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //screen separator
            int screenSep = 0;

            if (Int32.TryParse(textBox7.Text, out int sSep))
            {
                screenSep = sSep;
            }
            else
            {
                MessageBox.Show("Value: " + textBox7.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //check if screen separator is an even or odd number
            if (screenSep % 2 != 0)
            {
                MessageBox.Show("Value: " + textBox7.Text + " is an odd number! I'll increment it by 1...", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                screenSep += 1;
            }

            //read numerical values from textbox into int array
            int[] coordinateValues = new int[8];
            int index = 0;

            if (richTextBox1.Text.Length == 0)
            {
                MessageBox.Show("There are no values available in the textbox to create an image!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                string[] RichTextBoxLines = richTextBox1.Lines;
                foreach (string line in RichTextBoxLines)
                {
                    if (Regex.IsMatch(line, @"=\d"))
                    {
                        try
                        {
                            string numberOnly = Regex.Replace(line, @"[^\d]", "");
                            if (Int32.TryParse(numberOnly, out int numToAdd))
                            {
                                coordinateValues[index] = numToAdd;
                                index++;
                            }
                        }
                        catch (Exception)
                        {
                            MessageBox.Show("Error while trying to get the values from textbox! Do you have all 8 required values?", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }

            //store values from int array
            int custom_top_left = 0;
            int custom_top_top = 0;
            int custom_top_right = 0;
            int custom_top_bottom = 0;
            int custom_bottom_left = 0;
            int custom_bottom_top = 0;

            try
            {
                custom_top_left = coordinateValues[0];
                custom_top_top = coordinateValues[1];
                custom_top_right = coordinateValues[2];
                custom_top_bottom = coordinateValues[3];
                custom_bottom_left = coordinateValues[4];
                custom_bottom_top = coordinateValues[5];
            }
            catch (Exception)
            {
                MessageBox.Show("Error while trying to set the 8 values...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            Bitmap bitmap = new Bitmap(screenW, screenH, System.Drawing.Imaging.PixelFormat.Format32bppPArgb);
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                //black background
                using (System.Drawing.SolidBrush blackBrush = new System.Drawing.SolidBrush(System.Drawing.Color.Black))
                {
                    g.FillRectangle(blackBrush, new Rectangle(0, 0, screenW, screenH));
                }

                if (radioButton7.Checked == true) //centered or side-by-side (need no change)
                {
                    //red top screen
                    using (System.Drawing.SolidBrush redBrush = new System.Drawing.SolidBrush(System.Drawing.Color.Red))
                    {
                        //0, 0 -> left->right, up->down
                        g.FillRectangle(redBrush, new Rectangle(custom_top_left, custom_top_top, topsW, topsH));
                    }

                    //blue bottom screen
                    using (System.Drawing.SolidBrush blueBrush = new System.Drawing.SolidBrush(System.Drawing.Color.Blue))
                    {
                        //0, 0 -> left->right, up->down
                        g.FillRectangle(blueBrush, new Rectangle(custom_bottom_left, (custom_bottom_top - screenSep) + screenSep, btmsW, btmsH));
                    }
                }

                if (radioButton9.Checked == true) //in set
                {
                    //red top screen
                    using (System.Drawing.SolidBrush redBrush = new System.Drawing.SolidBrush(System.Drawing.Color.Red))
                    {
                        //0, 0 -> left->right, up->down
                        g.FillRectangle(redBrush, new Rectangle(custom_top_left, custom_top_top, custom_top_right - custom_top_left, custom_top_bottom));
                    }

                    //blue bottom screen
                    using (System.Drawing.SolidBrush blueBrush = new System.Drawing.SolidBrush(System.Drawing.Color.Blue))
                    {
                        //0, 0 -> left->right, up->down
                        g.FillRectangle(blueBrush, new Rectangle(custom_bottom_left, (custom_bottom_top - screenSep) + screenSep, btmsW, btmsH));
                    }
                }

            }

            try
            {
                bitmap.Save(screenW + "x" + screenH + ".jpg");
                MessageBox.Show("Image saved as: " + screenW + "x" + screenH + ".jpg", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception)
            {
                MessageBox.Show("Couldn't save the image to disk: " + screenW + "x" + screenH + ".jpg", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string config_path = textBox8.Text;

            if (string.IsNullOrWhiteSpace(richTextBox1.Text))
            {
                MessageBox.Show("There are no values available in the textbox to edit the config!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            INIFile inif = new INIFile(config_path);
            string[] RichTextBoxLines = richTextBox1.Lines;

            foreach (string line in RichTextBoxLines)
            {
                if (string.IsNullOrWhiteSpace(line))
                {
                    continue;
                }

                try
                {
                    string stringOnly = Regex.Replace(line, @"\=.*$", "");
                    string valueOnly = Regex.Replace(line, @".*=(.*)", "$1");

                    string[] layoutOptions = {
                    "custom_layout", "custom_top_left", "custom_top_top",
                    "custom_top_right", "custom_top_bottom", "custom_bottom_left",
                    "custom_bottom_top", "custom_bottom_right", "custom_bottom_bottom"
                    };

                    foreach (string layoutOption in layoutOptions)
                    {
                        if (stringOnly == layoutOption || stringOnly == layoutOption + "\\default")
                        {
                            inif.Write("Layout", stringOnly, valueOnly);
                            break;
                        }
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("There was an error trying to update this file: " + config_path, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            MessageBox.Show("This file has been updated with the textbox's values: " + config_path, "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        class INIFile
        {
            private string filePath;

            [DllImport("kernel32")]
            private static extern long WritePrivateProfileString(string section,
            string key,
            string val,
            string filePath);

            [DllImport("kernel32")]
            private static extern int GetPrivateProfileString(string section,
            string key,
            string def,
            StringBuilder retVal,
            int size,
            string filePath);

            public INIFile(string filePath)
            {
                this.filePath = filePath;
            }

            public void Write(string section, string key, string value)
            {
                WritePrivateProfileString(section, key, value.ToLower(), this.filePath);
            }

            public string Read(string section, string key)
            {
                StringBuilder SB = new StringBuilder(255);
                int i = GetPrivateProfileString(section, key, "", SB, 255, this.filePath);
                return SB.ToString();
            }

            public string FilePath
            {
                get { return this.filePath; }
                set { this.filePath = value; }
            }
        }

    }
}
