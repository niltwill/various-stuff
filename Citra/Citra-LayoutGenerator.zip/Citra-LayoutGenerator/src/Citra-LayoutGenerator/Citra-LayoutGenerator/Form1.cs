﻿using System;
using System.Windows.Forms;

namespace Citra_LayoutGenerator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //screen resolution
            int screenW = 0;
            int screenH = 0;

            if (Int32.TryParse(textBox5.Text, out int sW))
            {
                screenW = sW;
            }
            else
            {
                MessageBox.Show("Value: " + textBox5.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (Int32.TryParse(textBox6.Text, out int sH))
            {
                screenH = sH;
            }
            else
            {
                MessageBox.Show("Value: " + textBox6.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //top screen
            int topsW = 0;
            int topsH = 0;

            if (Int32.TryParse(textBox1.Text, out int tW))
            {
                topsW = tW;
            }
            else
            {
                MessageBox.Show("Value: " + textBox1.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (Int32.TryParse(textBox2.Text, out int tH))
            {
                topsH = tH;
            }
            else
            {
                MessageBox.Show("Value: " + textBox2.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //bottom screen
            int btmsW = 0;
            int btmsH = 0;

            if (Int32.TryParse(textBox3.Text, out int bW))
            {
                btmsW = bW;
            }
            else
            {
                MessageBox.Show("Value: " + textBox3.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (Int32.TryParse(textBox4.Text, out int bH))
            {
                btmsH = bH;
            }
            else
            {
                MessageBox.Show("Value: " + textBox4.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //screen separator
            int screenSep = 0;

            if (Int32.TryParse(textBox7.Text, out int sSep))
            {
                screenSep = sSep;
            }
            else
            {
                MessageBox.Show("Value: " + textBox7.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //check if screen separator is an even or odd number
            if (screenSep % 2 != 0)
            {
                MessageBox.Show("Value: " + textBox7.Text + " is an odd number! I'll increment it by 1...", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                screenSep += 1;
            }
            
            int screenSep2 = screenSep / 2;

            //check for bigger resolution errors
            if (topsH + btmsH > screenH)
            {
                MessageBox.Show("The top screen and bottom screen cannot fit into this screen resolution (considering height)!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (topsW > screenW)
            {
                MessageBox.Show("The top screen's width is bigger than the screen resolution's width!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (btmsW > screenW)
            {
                MessageBox.Show("The bottom screen's width is bigger than the screen resolution's width!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //remove previous generation
            richTextBox1.Clear();

            //calculate top screen's sizes
            int topScreenLeftRight = (screenW - topsW) / 2;
            int screenUpDownSize = (screenH - topsH - btmsH) / 2 - screenSep2;
            int topRightSize = topScreenLeftRight + topsW;
            int topBottomSize = screenUpDownSize + topsH;

            //calculate bottom screen's sizes
            int bottomScreenLeftRight = (screenW - btmsW) / 2;
            int bottomTopSize = topBottomSize + screenSep;
            int bottomRightSize = bottomScreenLeftRight + btmsW;
            int bottomBottomSize = screenH - screenUpDownSize;

            //check for minus values
            if (topScreenLeftRight < 0 || screenUpDownSize < 0 || topRightSize < 0 || topBottomSize < 0
                || bottomScreenLeftRight < 0 || bottomTopSize < 0 || bottomRightSize < 0 || bottomBottomSize < 0)
            {
                MessageBox.Show("At least one of the calculated values was in minus! Check if the screen resolutions are optimized properly.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //add the values to the textbox
            richTextBox1.AppendText("custom_layout\\default=false\r\n");
            richTextBox1.AppendText("custom_layout=true\r\n");
            richTextBox1.AppendText("custom_top_left\\default=false\r\n");
            richTextBox1.AppendText("custom_top_left=" + topScreenLeftRight.ToString() + "\r\n");
            richTextBox1.AppendText("custom_top_top\\default=false\r\n");
            richTextBox1.AppendText("custom_top_top=" + screenUpDownSize.ToString() + "\r\n");
            richTextBox1.AppendText("custom_top_right\\default=false\r\n");
            richTextBox1.AppendText("custom_top_right=" + topRightSize.ToString() + "\r\n");
            richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
            richTextBox1.AppendText("custom_top_bottom=" + topBottomSize.ToString() + "\r\n");
            richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
            richTextBox1.AppendText("custom_bottom_left=" + bottomScreenLeftRight.ToString() + "\r\n");
            richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
            richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
            richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
            richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
            richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
            richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //screen resolution
            int screenW = 0;
            int screenH = 0;

            if (Int32.TryParse(textBox5.Text, out int sW))
            {
                screenW = sW;
            }
            else
            {
                MessageBox.Show("Value: " + textBox5.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (Int32.TryParse(textBox6.Text, out int sH))
            {
                screenH = sH;
            }
            else
            {
                MessageBox.Show("Value: " + textBox6.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //top screen
            int topsW = 0;
            int topsH = 0;

            if (Int32.TryParse(textBox1.Text, out int tW))
            {
                topsW = tW;
            }
            else
            {
                MessageBox.Show("Value: " + textBox1.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (Int32.TryParse(textBox2.Text, out int tH))
            {
                topsH = tH;
            }
            else
            {
                MessageBox.Show("Value: " + textBox2.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //bottom screen
            int btmsW = 0;
            int btmsH = 0;

            if (Int32.TryParse(textBox3.Text, out int bW))
            {
                btmsW = bW;
            }
            else
            {
                MessageBox.Show("Value: " + textBox3.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (Int32.TryParse(textBox4.Text, out int bH))
            {
                btmsH = bH;
            }
            else
            {
                MessageBox.Show("Value: " + textBox4.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //screen separator
            int screenSep = 0;

            if (Int32.TryParse(textBox7.Text, out int sSep))
            {
                screenSep = sSep;
            }
            else
            {
                MessageBox.Show("Value: " + textBox7.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //check if screen separator is an even or odd number
            if (screenSep % 2 != 0)
            {
                MessageBox.Show("Value: " + textBox7.Text + " is an odd number! I'll increment it by 1...", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                screenSep += 1;
            }

            int screenSep2 = screenSep / 2;

            //check for bigger resolution errors
            /*if (topsH + btmsH > screenH)
            {
                MessageBox.Show("The top screen and bottom screen cannot fit into this screen resolution (considering height)!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }*/

            if (topsW > screenW)
            {
                MessageBox.Show("The top screen's width is bigger than the screen resolution's width!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (btmsW > screenW)
            {
                MessageBox.Show("The bottom screen's width is bigger than the screen resolution's width!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //remove previous generation
            richTextBox1.Clear();

            //calculate top screen's sizes
            int topScreenLeftRight = (screenW - (topsW + btmsW)) / 2 - screenSep2;
            int screenUpDownSize = (screenH - topsH) / 2;
            int topRightSize = topScreenLeftRight + topsW;
            int topBottomSize = screenUpDownSize + topsH;

            //calculate bottom screen's sizes
            int bottomScreenLeftRight = topRightSize + screenSep;
            int bottomTopSize = (screenH - btmsH) / 2;
            int bottomRightSize = screenW - topScreenLeftRight;
            int bottomBottomSize = bottomTopSize + btmsH;

            //check for minus values
            if (topScreenLeftRight < 0 || screenUpDownSize < 0 || topRightSize < 0 || topBottomSize < 0
                || bottomScreenLeftRight < 0 || bottomTopSize < 0 || bottomRightSize < 0 || bottomBottomSize < 0)
            {
                MessageBox.Show("At least one of the calculated values was in minus! Check if the screen resolutions are optimized properly.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //add the values to the textbox
            richTextBox1.AppendText("custom_layout\\default=false\r\n");
            richTextBox1.AppendText("custom_layout=true\r\n");
            richTextBox1.AppendText("custom_top_left\\default=false\r\n");
            richTextBox1.AppendText("custom_top_left=" + topScreenLeftRight.ToString() + "\r\n");
            richTextBox1.AppendText("custom_top_top\\default=false\r\n");
            richTextBox1.AppendText("custom_top_top=" + screenUpDownSize.ToString() + "\r\n");
            richTextBox1.AppendText("custom_top_right\\default=false\r\n");
            richTextBox1.AppendText("custom_top_right=" + topRightSize.ToString() + "\r\n");
            richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
            richTextBox1.AppendText("custom_top_bottom=" + topBottomSize.ToString() + "\r\n");
            richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
            richTextBox1.AppendText("custom_bottom_left=" + bottomScreenLeftRight.ToString() + "\r\n");
            richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
            richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
            richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
            richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
            richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
            richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //screen resolution
            int screenW = 0;
            int screenH = 0;

            if (Int32.TryParse(textBox5.Text, out int sW))
            {
                screenW = sW;
            }
            else
            {
                MessageBox.Show("Value: " + textBox5.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (Int32.TryParse(textBox6.Text, out int sH))
            {
                screenH = sH;
            }
            else
            {
                MessageBox.Show("Value: " + textBox6.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //bottom screen
            int btmsW = 0;
            int btmsH = 0;

            if (Int32.TryParse(textBox3.Text, out int bW))
            {
                btmsW = bW;
            }
            else
            {
                MessageBox.Show("Value: " + textBox3.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (Int32.TryParse(textBox4.Text, out int bH))
            {
                btmsH = bH;
            }
            else
            {
                MessageBox.Show("Value: " + textBox4.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //check for bigger resolution errors
            if (btmsW > screenW)
            {
                MessageBox.Show("The bottom screen's width is bigger than the screen resolution's width!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //remove previous generation
            richTextBox1.Clear();

            //calculate new dimensions based on aspect ratio
            float newWidth, newHeight, dif;

            //16:9
            newWidth = (float)screenW / 16;
            newHeight = (float)screenH / 9;
            if(newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //4:3
            newWidth = (float)screenW / 4;
            newHeight = (float)screenH / 3;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //3:2
            newWidth = (float)screenW / 3;
            newHeight = (float)screenH / 2;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //5:3
            newWidth = (float)screenW / 5;
            newHeight = (float)screenH / 3;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //5:4
            newWidth = (float)screenW / 5;
            newHeight = (float)screenH / 4;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //8:5
            newWidth = (float)screenW / 8;
            newHeight = (float)screenH / 5;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //9:5
            newWidth = (float)screenW / 9;
            newHeight = (float)screenH / 5;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //21:9
            newWidth = (float)screenW / 21;
            newHeight = (float)screenH / 9;
            newWidth = (int)Math.Floor(newWidth);
            dif = newWidth - newHeight;
            newWidth = (float)newWidth - dif;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //25:11
            newWidth = (float)screenW / 25;
            newHeight = (float)screenH / 11;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //25:12
            newWidth = (float)screenW / 25;
            newHeight = (float)screenH / 12;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //25:16
            newWidth = (float)screenW / 25;
            newHeight = (float)screenH / 16;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //32:9
            newWidth = (float)screenW / 32;
            newHeight = (float)screenH / 9;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //32:10
            newWidth = (float)screenW / 32;
            newHeight = (float)screenH / 10;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //32:25
            newWidth = (float)screenW / 32;
            newHeight = (float)screenH / 25;
            if (newWidth == newHeight)
            {
                int blackbar = (int)Math.Floor(newWidth) / 2;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }

            //1366x768
            if (screenW == 1366 && screenH == 768)
            {
                int blackbar = 214;
                int screenRightSize = screenW - blackbar;
                int bottomLeftSize = 0;
                int bottomRightSize = screenRightSize;
                int bottomTopSize = 0;
                int bottomBottomSize = screenH;

                if (radioButton1.Checked == true) //bottom right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomTopSize = screenH - btmsH;
                }
                if (radioButton2.Checked == true) //top right
                {
                    bottomLeftSize = (screenW - btmsW) - blackbar;
                    bottomBottomSize = btmsH;
                }
                if (radioButton3.Checked == true) //bottom left
                {
                    bottomLeftSize = blackbar;
                    bottomTopSize = screenH - btmsH;
                    bottomRightSize = blackbar + btmsW;
                }
                if (radioButton4.Checked == true) //top left
                {
                    bottomLeftSize = blackbar;
                    bottomRightSize = blackbar + btmsW;
                    bottomBottomSize = btmsH;
                }

                richTextBox1.AppendText("custom_layout\\default=false\r\n");
                richTextBox1.AppendText("custom_layout=true\r\n");
                richTextBox1.AppendText("custom_top_left\\default=false\r\n");
                richTextBox1.AppendText("custom_top_left=" + blackbar.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_top\\default=true\r\n");
                richTextBox1.AppendText("custom_top_top=0\r\n");
                richTextBox1.AppendText("custom_top_right\\default=false\r\n");
                richTextBox1.AppendText("custom_top_right=" + screenRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_top_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_top_bottom=" + screenH.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_left\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_left=" + bottomLeftSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_top\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_top=" + bottomTopSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_right\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_right=" + bottomRightSize.ToString() + "\r\n");
                richTextBox1.AppendText("custom_bottom_bottom\\default=false\r\n");
                richTextBox1.AppendText("custom_bottom_bottom=" + bottomBottomSize.ToString() + "\r\n");
                return;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //screen resolution
            int screenW = 0;
            int screenH = 0;

            if (Int32.TryParse(textBox5.Text, out int sW))
            {
                screenW = sW;
            }
            else
            {
                MessageBox.Show("Value: " + textBox5.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (Int32.TryParse(textBox6.Text, out int sH))
            {
                screenH = sH;
            }
            else
            {
                MessageBox.Show("Value: " + textBox6.Text + " is not an integer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (radioButton5.Checked == true) //centered
            {
                //restore default values
                int topsW = 400;
                int topsH = 240;
                int btmsW = 320;
                int btmsH = 240;

                textBox1.Text = topsW.ToString();
                textBox2.Text = topsH.ToString();
                textBox3.Text = btmsW.ToString();
                textBox4.Text = btmsH.ToString();

                //calculate height of two screens first
                float calculatedHeightMultiplier = screenH / (float)(topsH + btmsH);
                int calculatedHeightMultiplier_final = (int)Math.Floor(calculatedHeightMultiplier);
                int topScreenHeight = topsH * calculatedHeightMultiplier_final;
                int bottomScreenHeight = btmsH * calculatedHeightMultiplier_final;

                int calculatedHeightMultiplier2 = (int)Math.Ceiling(calculatedHeightMultiplier);
                float remainderOfMultiplier = calculatedHeightMultiplier2 - (float)calculatedHeightMultiplier;

                //for debugging only
                //MessageBox.Show(calculatedHeightMultiplier.ToString());
                //MessageBox.Show(calculatedHeightMultiplier2.ToString());
                //MessageBox.Show(remainderOfMultiplier.ToString());

                if (remainderOfMultiplier > 0.34 && remainderOfMultiplier < 0.5 && remainderOfMultiplier != 0 && screenW <= 1920) // top screen can be 2x bigger, bottom screen has to remain unchanged
                {
                    int topScreenWidth1 = topsW * 2; //2x
                    textBox1.Text = topScreenWidth1.ToString();

                    topScreenHeight = topsH * 2; //2x
                    textBox2.Text = topScreenHeight.ToString();
                }
                else if (remainderOfMultiplier == 0.5 && remainderOfMultiplier != 0 && screenW <= 1920) //top screen can be 1.5x bigger
                {
                    double topScreenWidth1 = topsW + (topsW * 0.5); //1.5x
                    textBox1.Text = topScreenWidth1.ToString();

                    double topScreenHeight1 = topsH + (topsH * 0.5); //1.5x
                    topScreenHeight = (int)topScreenHeight1;
                    textBox2.Text = topScreenHeight.ToString();
                }
                else if (remainderOfMultiplier <= 0.34 && remainderOfMultiplier != 0 && screenW <= 1920) //1.5x for both?
                {
                    double topScreenWidth1 = topsW + (topsW * 0.5); //1.5x
                    textBox1.Text = topScreenWidth1.ToString();

                    double topScreenHeight1 = topsH + (topsH * 0.5); //1.5x
                    topScreenHeight = (int)topScreenHeight1;
                    textBox2.Text = topScreenHeight.ToString();

                    double bottomScreenWidth1 = btmsW + (btmsW * 0.5); //1.5x
                    textBox3.Text = bottomScreenWidth1.ToString();

                    double bottomScreenHeight1 = btmsH + (btmsH * 0.5); //1.5x
                    bottomScreenHeight = (int)bottomScreenHeight1;
                    textBox4.Text = bottomScreenHeight.ToString();
                }
                else
                {
                    double topScreenWidth2 = topScreenHeight * 1.666666666666667; //400 / 240
                    int topScreenWidthFin = (int)Math.Round(topScreenWidth2);
                    textBox1.Text = topScreenWidthFin.ToString();

                    double bottomScreenWidth2 = bottomScreenHeight * 1.333333333333333; //320 / 240
                    int bottomScreenWidthFin = (int)Math.Round(bottomScreenWidth2);
                    textBox3.Text = bottomScreenWidthFin.ToString();
                }

                textBox2.Text = topScreenHeight.ToString();
                textBox4.Text = bottomScreenHeight.ToString();

                if(topScreenHeight + bottomScreenHeight == screenH) //step back one for bottom screen
                {
                    string bottomScreenWidth = textBox3.Text;
                    int bottomScrW = int.Parse(bottomScreenWidth) - 320;
                    textBox3.Text = bottomScrW.ToString();

                    string bottomScreenHeight2 = textBox4.Text;
                    int bottomScrH = int.Parse(bottomScreenHeight2) - 240;
                    textBox4.Text = bottomScrH.ToString();
                }

            }

            if (radioButton6.Checked == true) //side-by-side
            {
                //restore default values
                int topsW = 400;
                int topsH = 240;
                int btmsW = 320;
                int btmsH = 240;

                textBox1.Text = topsW.ToString();
                textBox2.Text = topsH.ToString();
                textBox3.Text = btmsW.ToString();
                textBox4.Text = btmsH.ToString();

                //width is the deciding factor, which is to be computed first
                float calculatedWidthMultiplier = screenW / (float)(topsW + btmsW);
                int calculatedWidthMultiplier_final = (int)Math.Floor(calculatedWidthMultiplier);
                int topScreenWidth = topsW * calculatedWidthMultiplier_final;
                int bottomScreenWidth = btmsW * calculatedWidthMultiplier_final;
                int topScreenHeight = topsH * calculatedWidthMultiplier_final;
                int bottomScreenHeight = btmsH * calculatedWidthMultiplier_final;

                int calculatedWidthMultiplier2 = (int)Math.Ceiling(calculatedWidthMultiplier);
                float remainderOfMultiplier = calculatedWidthMultiplier2 - (float)calculatedWidthMultiplier;

                //for debugging only
                //MessageBox.Show(calculatedWidthMultiplier.ToString());
                //MessageBox.Show(calculatedWidthMultiplier2.ToString());
                //MessageBox.Show(remainderOfMultiplier.ToString());

                if (remainderOfMultiplier < 0.32 && remainderOfMultiplier != 0 && screenW <= 1920)
                {
                    //1.5x
                    double topScreenWidth1 = topsW + (topsW * 0.5); //1.5x
                    topScreenWidth = (int)topScreenWidth1;
                    textBox1.Text = topScreenWidth.ToString();

                    double topScreenHeight1 = topsH + (topsH * 0.5); //1.5x
                    topScreenHeight = (int)topScreenHeight1;
                    textBox2.Text = topScreenHeight.ToString();

                    double bottomScreenWidth1 = btmsW + (btmsW * 0.5); //1.5x
                    bottomScreenWidth = (int)bottomScreenWidth1;
                    textBox3.Text = bottomScreenWidth.ToString();

                    double bottomScreenHeight1 = btmsH + (btmsH * 0.5); //1.5x
                    bottomScreenHeight = (int)bottomScreenHeight1;
                    textBox4.Text = bottomScreenHeight.ToString();
                } else if (remainderOfMultiplier > 0.10 && remainderOfMultiplier != 0)
                {

                    if(topScreenWidth + 400 < bottomScreenWidth)
                    {
                        topScreenWidth = topScreenWidth + 400;
                    }

                    if(topScreenHeight + 240 < bottomScreenHeight)
                    {
                        topScreenHeight = topScreenHeight + 240;
                    }

                    textBox1.Text = topScreenWidth.ToString();
                    textBox2.Text = topScreenHeight.ToString();

                    if(btmsW != 320)
                    {
                        double bottomScreenWidth1 = btmsW + (btmsW * 0.5); //1.5x
                        bottomScreenWidth = (int)bottomScreenWidth1;
                    }
                    textBox3.Text = bottomScreenWidth.ToString();

                    if(btmsH != 240)
                    {
                        double bottomScreenHeight1 = btmsH + (btmsH * 0.5); //1.5x
                        bottomScreenHeight = (int)bottomScreenHeight1;
                    }
                    textBox4.Text = bottomScreenHeight.ToString();

                    //textBox1.Text = topScreenWidth.ToString();
                    //textBox2.Text = topScreenHeight.ToString();
                    //textBox3.Text = bottomScreenWidth.ToString();
                    //textBox4.Text = bottomScreenHeight.ToString();
                }

                if(topScreenWidth + bottomScreenWidth >= screenW)  //step back one for bottom screen
                {
                    string bottomScreenW = textBox3.Text;
                    int bottomScrW = int.Parse(bottomScreenW) - 320;
                    textBox3.Text = bottomScrW.ToString();

                    string bottomScreenH = textBox4.Text;
                    int bottomScrH = int.Parse(bottomScreenH) - 240;
                    textBox4.Text = bottomScrH.ToString();
                }

                //fix too much height
                if(topScreenHeight >= screenH)
                {
                    string topScreenH = textBox2.Text;
                    int topScrH = (int.Parse(topScreenH) - screenH) * 2;
                    topScreenHeight = topScreenHeight - topScrH;
                    textBox2.Text = topScreenHeight.ToString();
                }

                if (bottomScreenHeight >= screenH)
                {
                    string bottomScreenH = textBox4.Text;
                    int bottomScrH = (int.Parse(bottomScreenH) - screenH) * 2;
                    bottomScreenHeight = bottomScreenHeight - bottomScrH;
                    textBox4.Text = bottomScreenHeight.ToString();
                }
            }
        }

        private void richTextBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                richTextBox1.SelectAll();
                try
                {
                    Clipboard.SetText(richTextBox1.SelectedText);
                }
                catch (ArgumentNullException)
                {
                    MessageBox.Show("Nothing is selected here or nothing can be selected.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                catch (Exception)
                {
                    MessageBox.Show("Error while handling the textbox!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

    }
}
