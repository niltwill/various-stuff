﻿This is a little program that can generate custom layouts for the Citra emulator's config in three ways:

1. centered
2. side-by-side
3. in set

Note that the generated values only correctly display when using fullscreen mode (F11). If you want to play it without fullscreen, you'll have to manually adjust the positions yourself.

Both "centered" and "side-by-side" require every textbox to be filled. No strings are allowed, only integers. Remember that the original screen sizes are: 400x240 for top screen and 320x240 for bottom screen. So these two sizes can be multiplied, for best accuracy, the aspect ratio should remain 5:3 for the top screen and 4:3 for the bottom screen. If you do some math calculations, you can figure out what you need (keeping in mind the width and height limitations for both screens, so that it can fit on your screen).

If you can't be bothered to calculate it, then a good start is to select "Centered" or "Side-by-side" and click on the "Calculate recommended size" button (this has been grouped together). It will change the top and bottom screen to what the program recommends for either centered or the side-by-side layout. It is a rough guideline that may or may not be optimal for your use case. You may, for example, want to have 3x bigger top screen and 2x bigger bottom screen, instead of both 2x bigger top screen and bottom screen, so you may wish to change the result afterward. Do note that this function may be a little buggy or not work well with certain resolutions. Very big screen resolutions were not tested.

For example, for 1920x1080, you could use 800x480 for top screen (2x enlarged) and 640x480 for bottom screen (2x enlarged) - in case of the centered layout. The two screens' height is 960 pixels, leaving 120 pixels free, which have to be divided by two for the top and bottom side, so 60 remain, and because of the screen separation, 4 has to be cut from each side, so that the spacing of 8 pixels can occur between the two screens.

For the same screen resolution (1920x1080), another example would be 1200x720 for top screen (3x enlarged) and 480x360 for bottom screen (1.5x enlarged) - for the side-by-side layout. The width required is 1680 for the two screens, which can fit into 1920, leaving 240 pixels (-> 120 for left and right, plus the cost of spacing).

"Screen separator in pixels" is the spacing between the two screens, so that they don't merge into each other. This should be an even number, not odd, since it's used to calculate two sides. Can be 0, if you don't want this. Any odd number here will be incremented by one. This value is only used in the "centered" and "side-by-side" generation.

"In set" only requires the screen resolution's width and height, and the bottom screen's width and height. The top screen will basically fill your entire screen resolution, with the bottom screen being put at one of the 4 edges of the inside of the top screen: top left, top right, bottom left, bottom right. There will be black bars at the left and right side of the screen, according to the aspect ratio. This only supports 1:1 for the following aspect ratios; 2:1, 3:2, 5:3, 5:4, 8:5, 9:5, 16:9, 16:10, 17:10, 21:9, 25:11, 25:12, 25:16, 32:9, 32:10, 32:25, 64:27, 70:30... Most common screen resolutions should work, including 1366x768 (but this may require adjustment). Also, if your screen resolution's height is way bigger than the width (mostly phones and similar portable devices, e.g. 1080x2280), you may also want to tick the "Resize to center" checkbox, as the full top to bottom stretch is going to look horrendous. This centered size may not be the most ideal either, but at least it should be better.

---

Once you have the generated values, you can check out an example of how it would look like, by pressing "Generate preview image...", but also select either "...for centered / side-by-side" or "...for in set", depending on what you used for generating the values. This will save a JPG image in the same directory as this little program, named as: "[screen width]x[screen height].jpg"
Red rectangle is the top screen, and the blue rectangle is the bottom screen. Any existing image will be overwritten.

Finally, you can type in the file path for Citra's "qt-config.ini" config file (where the layout settings can be found).
For this file to exist, you'd have to run the Citra emulator first to initialize it, and then quit from the emulator. Otherwise it may not exist yet.

In Windows, this should be located in: "C:\Users\<username>\AppData\Roaming\Citra\config\qt-config.ini"
By default, the program attempts to use your username (with which you're currently logged in), so in most cases, the file path should be alright.

When using Wine, while running a Linux distribution, the program assumes this to be within your user folder in /home, and within that: ".config/citra-emu/qt-config.ini"

That's because during my test, the installer for Linux used Flatpak for Citra, and stored the "qt-config.ini" in the location mentioned earlier.
This should be correct, but it might be located elsewhere. If so, change that path to your actual "qt-config.ini" file's location.
Mac OS X should also store that file in a similar place (but here your user folder is in "/Users" instead of "/home"), so change "home" to "Users".

Once the correct path is set to that file, click on the "Edit qt-config.ini" button, and your layout values will be changed.
But beware, that the program does not create a backup of this config file, so your already existing layout will be lost!

Make sure to close Citra first (if opened already) before editing that configuration file. You can either try to use the program's auto replace with the button (as explained earlier), or do it manually.

If you want to do this manually, you can copy and paste the values as is. You can copy by either left-clicking in the textbox and selecting every line, then pressing Ctrl+C, or by a simple right-click inside the textbox, after the values have been generated. A single right-click will copy all the contents inside the textbox into the clipboard, so then you can paste it into the appropriate part of the config file.

---

If you want a dual monitor setup without ugly edges or unused black screen areas (to display top screen and bottom screen on different monitors at full size), check out this guide:
https://community.citra-emu.org/t/guide-dual-monitor-setup-noob-friendly/539526

I can confirm it is working, although having to use a separate application called "Borderless Gaming" after every update can get rather tedious. It is also a Windows-centric approach.

---

What's left to do: try to improve the aspect ratio stuff for the "in set" generator, and the "recommended size calculator".
Other than that, for any interested developer: using this source code, it could be ported to Python, C or some other portable programming language to make it more OS agnostic, with a configuration file and/or CLI parameters. Also perhaps if possible, one could port it to Mono, so that a native binary app could be created for Linux. The program does run using "Wine" under Linux (I tried it with Linux Mint), and function as expected.
